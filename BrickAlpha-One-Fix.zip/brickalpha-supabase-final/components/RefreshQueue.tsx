"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import { ensureSupabaseUser, supabase } from "@/lib/supabase";

type Attempt = { inventory_id: string; setNumber?: string; name?: string; status: string; error?: string; attempted_at?: string };
type Reply = { ok: boolean; error?: string; queued: number; total: number; attempted?: number; processed: number; ready?: number; running?: number; waitingRetry?: number; needsReview?: number; passFinished?: boolean; attempts?: Attempt[] };
export default function RefreshQueue({ onProgress }: { onProgress?: () => void }) {
  const [running, setRunning] = useState(false), [note, setNote] = useState(""), [remaining, setRemaining] = useState<number | null>(null);
  const [review, setReview] = useState<Attempt[]>([]);
  const stop = useRef(false), inFlight = useRef(false), progress = useRef(onProgress);
  useEffect(() => { progress.current = onProgress; }, [onProgress]);
  useEffect(() => () => { stop.current = true; }, []);
  const request = useCallback(async (method: "GET" | "POST", body?: object): Promise<Reply> => {
    await ensureSupabaseUser();
    const { data } = await supabase.auth.getSession();
    if (!data.session) throw new Error("Sign in to access your collection.");
    const response = await fetch("/api/update", { method, headers: { Authorization: `Bearer ${data.session.access_token}`, "Content-Type": "application/json" }, body: body ? JSON.stringify(body) : undefined, cache: "no-store" });
    const result = await response.json();
    if (!response.ok || !result.ok) throw new Error(result.error || "Could not refresh the queue.");
    return result;
  }, []);
  const status = useCallback(async () => {
    const result = await request("GET");
    setRemaining(result.queued); setReview((result.attempts || []).filter(a => a.status === "needs_review")); return result;
  }, [request]);
  useEffect(() => { let active = true; const reload = () => { request("GET").then(result => { if (active) { setRemaining(result.queued); setReview((result.attempts || []).filter(a => a.status === "needs_review")); progress.current?.(); } }).catch(e => { if (active) setNote(e instanceof Error ? e.message : "Queue status unavailable."); }); }; reload(); const timer=setInterval(reload,15000); window.addEventListener("inventory-change", reload); return () => { active = false; clearInterval(timer); window.removeEventListener("inventory-change", reload); }; }, [request]);
  async function run(retry = false) {
    if (inFlight.current) return;
    inFlight.current = true; stop.current = false; setRunning(true); setNote("Searching completed sales and checking set condition…");
    let processed = 0, attempted = 0, first = true;
    try {
      while (!stop.current) {
        const result = await request("POST", { action: "run", retry: first && retry });
        first = false; processed += result.processed; attempted += result.attempted || 0; setRemaining(result.queued); progress.current?.();
        setNote(`Checked ${attempted} entries · updated ${processed} · ${result.queued} still queued`);
        if (result.passFinished) {
          const final = await status();
          setNote(final.queued === 0 ? `Finished. Updated ${processed} entries.` : `Pass saved. Updated ${processed}. ${final.running||0} researching, ${final.waitingRetry||0} awaiting retry, ${final.needsReview||0} need review.`); break;
        }
      }
      if (stop.current) setNote(`Paused after checking ${attempted} entries. Updated ${processed}; saved progress is ready to resume.`);
    } catch (e) { setNote(e instanceof Error ? e.message : "Research stopped. Saved progress is preserved."); }
    finally { inFlight.current = false; setRunning(false); }
  }
  return <section className="card" style={{ margin: "16px 0" }} aria-label="Price refresh queue">
    <div className="section-title"><h2>Search and update prices</h2>{remaining !== null ? <span className="pill amber">{remaining} queued</span> : null}</div>
    <p className="muted">Only the Queue and Queue all buttons add price requests. Background checks continue when this page is closed. After queuing, ask ChatGPT “Update my current Brick Alpha queue.” You can also search the existing queue here. Entries with insufficient evidence stay queued with a reason.</p>
    <div className="actions">
      <button className="btn accent" disabled={running} onClick={() => void run()}>Search queued sets</button>
      {review.length > 0 ? <button className="btn secondary" disabled={running} onClick={() => void run(true)}>Retry entries needing review</button> : null}
      {running ? <button className="btn secondary" onClick={() => { stop.current = true; setNote("Pausing after the current searches are saved…"); }}>Pause after this batch</button> : null}
    </div>
    <p role="status" aria-live="polite" style={{ marginBottom: 0 }}>{note}</p>
    {review.length > 0 ? <details style={{ marginTop: 12 }}><summary>{review.length} entries need review</summary><ul>{review.map(a => <li key={a.inventory_id}>#{a.setNumber||a.inventory_id} {a.name||""}: {a.error}</li>)}</ul></details> : null}
  </section>;
}
