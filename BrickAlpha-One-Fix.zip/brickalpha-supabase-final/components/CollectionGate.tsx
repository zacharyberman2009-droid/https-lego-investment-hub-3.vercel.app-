"use client";
import {useEffect,useState} from "react";
import {collectionOwnerId,supabase} from "@/lib/supabase";

export default function CollectionGate({children}:{children:React.ReactNode}){
  const [state,setState]=useState<"loading"|"ready"|"signin">("loading");
  const [email,setEmail]=useState(""),[password,setPassword]=useState(""),[notice,setNotice]=useState(""),[busy,setBusy]=useState(false);
  useEffect(()=>{
    let active=true;
    const check=async()=>{try{await collectionOwnerId();if(active){setState("ready");setNotice("");}}catch(e){if(active){setState("signin");setNotice(e instanceof Error?e.message:"Could not access your collection.");}}};
    void check();
    // Keep async Supabase calls outside the auth callback's internal lock.
    const {data}=supabase.auth.onAuthStateChange(()=>{queueMicrotask(()=>{if(active)void check();});});
    return()=>{active=false;data.subscription.unsubscribe();};
  },[]);
  async function signIn(link:boolean){
    setBusy(true);setNotice("");
    try{
      const result=link?await supabase.auth.signInWithOtp({email:email.trim(),options:{shouldCreateUser:false,emailRedirectTo:`${window.location.origin}/inventory`}}):await supabase.auth.signInWithPassword({email:email.trim(),password});
      if(result.error)throw result.error;
      if(link)setNotice("Check your email and open the newest sign-in link. Return to this page after signing in.");
      else{await collectionOwnerId();setState("ready");}
    }catch(e){setNotice(e instanceof Error?e.message:"Sign-in failed. Try again.");}
    finally{setBusy(false);}
  }
  if(state==="ready")return <>{children}</>;
  if(state==="loading")return <div className="notice" role="status">Checking access to your collection…</div>;
  return <section className="card" style={{maxWidth:540,margin:"40px auto"}}>
    <h1>Open your Brick Alpha collection</h1>
    <p className="muted">Sign in with the email linked to your existing collection.</p>
    <form onSubmit={e=>{e.preventDefault();void signIn(false);}}>
      <div className="field"><label htmlFor="collection-email">Email</label><input id="collection-email" type="email" autoComplete="email" required value={email} onChange={e=>setEmail(e.target.value)}/></div>
      <div className="field" style={{marginTop:12}}><label htmlFor="collection-password">Password</label><input id="collection-password" type="password" autoComplete="current-password" value={password} onChange={e=>setPassword(e.target.value)}/></div>
      <div className="actions" style={{marginTop:16}}><button className="btn accent" disabled={busy||!email||!password} type="submit">Sign in</button><button className="btn secondary" disabled={busy||!email} type="button" onClick={()=>void signIn(true)}>Email me a sign-in link</button></div>
    </form>
    <p role="status" aria-live="polite">{notice}</p>
    <div className="actions"><button className="btn secondary" disabled={busy} onClick={()=>{setState("loading");void collectionOwnerId().then(()=>setState("ready")).catch(e=>{setNotice(e.message);setState("signin");});}}>Check access again</button><button className="btn secondary" disabled={busy} onClick={()=>{void supabase.auth.signOut({scope:"local"}).then(()=>setNotice("Signed out on this device. Enter your linked email above."));}}>Switch account</button></div>
  </section>;
}
