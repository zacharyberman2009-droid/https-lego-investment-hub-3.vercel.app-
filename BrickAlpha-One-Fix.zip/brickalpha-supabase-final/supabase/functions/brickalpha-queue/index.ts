import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
};

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...cors, "Content-Type": "application/json", "Cache-Control": "no-store" },
  });
}

function cleanSources(value: unknown) {
  if (!Array.isArray(value)) return [];
  return value.slice(0, 12).map((s) => ({
    source: String(s?.source ?? "").slice(0, 80),
    label: String(s?.label ?? "").slice(0, 160),
    value: s?.value != null && Number.isFinite(Number(s.value)) ? Number(s.value) : undefined,
    condition: s?.condition ? String(s.condition) : undefined,
    observedCondition: s?.observedCondition ? String(s.observedCondition) : undefined,
    dataAsOf: s?.dataAsOf ? String(s.dataAsOf) : undefined,
    comps: Array.isArray(s?.comps) ? s.comps.slice(0, 50).map((c: any) => ({
      date: String(c?.date ?? ""), title: String(c?.title ?? "").slice(0, 300),
      price: Number(c?.price), url: String(c?.url ?? "").slice(0, 1000),
    })) : undefined,
    kind: ["sold", "estimate", "listing", "retail", "manual"].includes(String(s?.kind)) ? String(s.kind) : "estimate",
    detail: s?.detail ? String(s.detail).slice(0, 500) : undefined,
    url: s?.url ? String(s.url).slice(0, 1000) : undefined,
    fetchedAt: s?.fetchedAt ? String(s.fetchedAt).slice(0, 80) : new Date().toISOString(),
  }));
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });

  const auth = req.headers.get("Authorization");
  if (!auth?.startsWith("Bearer ")) return json({ ok: false, error: "Missing bearer token" }, 401);

  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const anonKey = Deno.env.get("SUPABASE_ANON_KEY");
  if (!supabaseUrl || !anonKey) return json({ ok: false, error: "Supabase function environment is incomplete" }, 500);

  const supabase = createClient(supabaseUrl, anonKey, {
    global: { headers: { Authorization: auth } },
    auth: { persistSession: false, autoRefreshToken: false, detectSessionInUrl: false },
  });

  const { data: userData, error: userError } = await supabase.auth.getUser();
  const user = userData?.user;
  if (userError || !user) return json({ ok: false, error: "Invalid session" }, 401);

  const { data: collectionOwner, error: ownerError } = await supabase.rpc("brickalpha_collection_owner");
  if (ownerError) return json({ ok: false, error: ownerError.message }, 400);
  const ownerId = typeof collectionOwner === "string" ? collectionOwner : user.id;

  if (req.method === "GET") {
    const { count: total, error: totalError } = await supabase
      .from("inventory_items")
      .select("id", { count: "exact", head: true })
      .eq("owner_id", ownerId);
    if (totalError) return json({ ok: false, error: totalError.message }, 400);

    const { data: queued, error: queueError } = await supabase
      .from("inventory_items")
      .select("id,set_number,name,condition,market,last_updated,refresh_requested_at")
      .eq("owner_id", ownerId)
      .eq("refresh_requested", true)
      .order("refresh_requested_at", { ascending: true, nullsFirst: true });
    if (queueError) return json({ ok: false, error: queueError.message }, 400);

    return json({
      ok: true,
      total: total ?? 0,
      queued: queued?.length ?? 0,
      oldestQueuedAt: queued?.[0]?.refresh_requested_at ?? null,
      items: queued ?? [],
    });
  }

  if (req.method !== "POST") return json({ ok: false, error: "Method not allowed" }, 405);

  let body: any = {};
  try { body = await req.json(); } catch { return json({ ok: false, error: "Invalid JSON" }, 400); }
  const action = String(body?.action ?? "");

  if (action === "queue-all") {
    const now = new Date().toISOString();
    const { error } = await supabase
      .from("inventory_items")
      .update({ refresh_requested: true, refresh_requested_at: now })
      .eq("owner_id", ownerId)
      .eq("refresh_requested", false);
    if (error) return json({ ok: false, error: error.message }, 400);
    return json({ ok: true, action, queuedAt: now });
  }

  if (action === "queue-stale") {
    return json({ ok: false, error: "Automatic queuing is disabled. Use Queue or Queue all." }, 400);
  }

  if (action === "complete") {
    const id = String(body?.id ?? "").trim();
    const market = Number(body?.market);
    if (!id) return json({ ok: false, error: "Missing inventory id" }, 400);
    if (!Number.isFinite(market) || market < 0 || market > 1000000) return json({ ok: false, error: "Invalid market value" }, 400);

    const sources = cleanSources(body?.sources);
    const { data, error } = await supabase.rpc("complete_price_refresh", {
      p_id: id,
      p_market: market,
      p_sources: sources,
    });
    if (error) {
      const status = error.message?.includes("not found") ? 404 : 400;
      return json({ ok: false, error: error.message }, status);
    }
    return json({ ok: true, action, item: data?.[0] ?? null, sourceCount: sources.length });
  }

  return json({ ok: false, error: "Unknown action" }, 400);
});

