import type { SupabaseClient } from "npm:@supabase/supabase-js@2.57.4";
import { researchMarket, type ResearchItem } from "./public-market.ts";

export async function runResearchBatch(db:SupabaseClient,owner:string,retry=false,limit=2){
  const {data:claim,error:claimError}=await db.rpc("claim_price_refresh",{p_limit:limit,p_retry:retry,p_owner_id:owner});
  if(claimError)throw new Error(claimError.message);
  const outcomes=await Promise.all((claim.items as ResearchItem[]).map(async item=>{
    try{
      const result=await researchMarket(item);
      const {data,error}=await db.rpc("brick_alpha_queue",{p_action:"complete",p_owner_id:owner,p_payload:{id:item.id,version:item.version,condition:item.condition,market:result.market,sources:result.sources,leaseToken:item.leaseToken}});
      if(error)throw new Error(error.message);
      return {id:item.id,setNumber:item.setNumber,status:"complete",market:data.market};
    }catch(e){
      const message=e instanceof Error?e.message:"Research failed";
      const {data,error}=await db.rpc("brickalpha_finish_attempt",{p_id:item.id,p_requested_at:item.requestedAt,p_lease_token:item.leaseToken,p_error:message,p_transient:/HTTP (403|408|429|5\d\d)|timeout|timed out|network|fetch failed|source unavailable|aborted/i.test(message),p_owner_id:owner});
      if(error)throw new Error(`Could not save research status: ${error.message}`);
      return {id:item.id,setNumber:item.setNumber,status:data.recorded?"deferred":"superseded",error:message};
    }
  }));
  const {data:state,error}=await db.rpc("brick_alpha_queue",{p_action:"status",p_owner_id:owner});
  if(error)throw new Error(error.message);
  return {...state,attempted:outcomes.length,processed:outcomes.filter(x=>x.status==="complete").length,items:outcomes,passFinished:state.ready===0};
}
