import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import {createClient} from "npm:@supabase/supabase-js@2.57.4";
import {runResearchBatch} from "./queue-processor.ts";

Deno.serve(async(req:Request)=>{
 const json=(body:unknown,status=200)=>Response.json(body,{status,headers:{"Cache-Control":"no-store"}});
 if(req.method!=="POST")return json({ok:false,error:"POST required"},405);
 const secret=req.headers.get("x-brickalpha-worker-secret");
 if(!secret||!/^[0-9a-f]{64}$/.test(secret))return json({ok:false,error:"Worker authentication required"},401);
 const db=createClient(Deno.env.get("SUPABASE_URL")!,Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,{auth:{persistSession:false,autoRefreshToken:false,detectSessionInUrl:false},global:{fetch:(url,options)=>fetch(url,{...options,signal:options?.signal?AbortSignal.any([options.signal,AbortSignal.timeout(12000)]):AbortSignal.timeout(12000)})}});
 const {data:allowed,error:authError}=await db.rpc("brickalpha_worker_authorize",{p_secret:secret});
 if(authError)return json({ok:false,error:`Worker verification unavailable: ${authError.message}`},503);
 if(allowed!==true)return json({ok:false,error:"Worker authentication failed"},401);
 let body:{dryRun?:boolean}={};try{body=await req.json();}catch{}
 try{
   const {data:rows,error}=await db.from("inventory_items").select("owner_id").eq("refresh_requested",true);
   if(error)throw new Error(error.message);
   const owners=[...new Set((rows||[]).map(row=>row.owner_id as string))];
   if(body.dryRun)return json({ok:true,dryRun:true,collections:owners.length});
   let attempted=0,processed=0,ready=0;
   // Short batches finish inside the edge runtime limit. A saved lease recovers interrupted runs.
   for(const owner of owners){
     const result=await runResearchBatch(db,owner,false,2);
     attempted+=result.attempted;processed+=result.processed;ready+=result.ready||0;
   }
   const {error:saveError}=await db.rpc("brickalpha_worker_record",{p_error:null});
   if(saveError)throw new Error(saveError.message);
   // Drain already requested work in more batches; this never creates new requests.
   if(ready>0){const {error:wakeError}=await db.rpc("brickalpha_wake_worker");if(wakeError)throw new Error(wakeError.message);}
   return json({ok:true,attempted,processed,ready});
 }catch(e){
   const message=e instanceof Error?e.message:"Background worker failed";
   await db.rpc("brickalpha_worker_record",{p_error:message.slice(0,1000)});
   return json({ok:false,error:message},500);
 }
});
