import { load } from "npm:cheerio@1.1.2";
import type { Condition, MarketSource } from "./types.ts";

export type Sale = { date: string; title: string; price: number; url: string };
export type ResearchItem = {
  id: string; setNumber: string; name: string; condition: Condition;
  currentMarket: number; requestedAt:string; leaseToken:string; marketSources?: MarketSource[]; version: string;
};
type Page = { html: string; url: string };
const ALLOWED_HOSTS = new Set(["www.pricecharting.com", "www.brickeconomy.com", "brickpricewatch.com", "www.bricklink.com"]);

function price(text: string): number | undefined {
  const m = text.match(/\$\s*([\d,]+(?:\.\d+)?)/);
  return m ? Number(m[1].replaceAll(",", "")) : undefined;
}
function median(values: number[]) {
  const sorted = [...values].sort((a, b) => a - b), middle = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[middle] : (sorted[middle - 1] + sorted[middle]) / 2;
}
function exactNumber(number: string) { return new RegExp(`(?<!\\d)${number}(?!\\d)`); }
async function page(url: string, signal?:AbortSignal): Promise<Page> {
  for (let redirect = 0; redirect <= 4; redirect++) {
    const parsed = new URL(url);
    if (parsed.protocol !== "https:" || !ALLOWED_HOSTS.has(parsed.hostname) || parsed.username || parsed.password || parsed.port) throw new Error("Unapproved market source");
    const response = await fetch(url, { headers: { "User-Agent": "Mozilla/5.0", Accept: "text/html" }, redirect: "manual", cache: "no-store", signal: signal?AbortSignal.any([signal,AbortSignal.timeout(12000)]):AbortSignal.timeout(12000) });
    if ([301, 302, 303, 307, 308].includes(response.status)) {
      const location = response.headers.get("location");
      if (!location) throw new Error("Market source returned an invalid redirect");
      url = new URL(location, url).href; continue;
    }
    if (response.status !== 200) throw new Error(`${parsed.hostname}: HTTP ${response.status}`);
    const html = await response.text();
    if (html.length < 4000 || html.length > 3000000 || /<title>[^<]*(captcha|access denied|verify|just a moment)/i.test(html)) throw new Error(`${parsed.hostname}: source unavailable`);
    return { html, url };
  }
  throw new Error("Market source returned too many redirects");
}
async function priceCharting(number: string, previous?: string, signal?:AbortSignal): Promise<Page> {
  let result: Page;
  try { result = await page(previous || `https://www.pricecharting.com/search-products?type=prices&q=${number}`,signal); }
  catch { result = await page(`https://www.pricecharting.com/search-products?type=prices&q=${number}`,signal); }
  if (new URL(result.url).pathname.startsWith("/game/")) return result;
  const $ = load(result.html);
  const links = new Set($("a[href*='/game/']").toArray().filter(a => exactNumber(number).test($(a).text())).map(a => $(a).attr("href")!));
  if (links.size !== 1) throw new Error("Exact PriceCharting product could not be resolved");
  return page(new URL([...links][0], "https://www.pricecharting.com").href,signal);
}

export function parseSales(html: string, number: string, condition: Condition, now: number): Sale[] {
  const $ = load(html);
  if (!exactNumber(number).test($("h1").first().text())) throw new Error("Completed-sales page identifies a different set");
  const groups = condition === "New/Sealed" ? ["new"] : ["cib", "used", "loose-and-manual"];
  const sales: Sale[] = [], seen = new Set<string>();
  for (const group of groups) {
    $(`.completed-auctions-${group} tr`).each((_, node) => {
      const row = $(node), date = row.find(".date").text().trim(), a = row.find(".title a").first();
      const title = a.text().replace(/\s+/g, " ").trim(), value = price(row.find("td.numeric .js-price").first().text());
      const url = (a.attr("href") || "").split("?")[0], age = (now - Date.parse(`${date}T00:00:00Z`)) / 86400000;
      if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || !value || !Number.isFinite(age) || age < 0 || age > 180 || !exactNumber(number).test(title) || seen.has(url)) return;
      seen.add(url);
      if (!/^https:\/\/www\.ebay\.com\/itm\/\d+$/.test(url)) return;
      if (/\b(pre[ -]?order|pre[ -]?sale|presale|deposit|reservation|digital|instructions only|only|replacement|light(?:ing)? kit|led kit|empty box|custom|compatible|knock.?off|bulk|bundle|lot of|set of [2-9]|[2-9] ?x|x ?[2-9])\b/i.test(title)) return;
      if (/\b(no|without|missing)\s+(all\s+)?(mini.?fig(?:ure)?s?|figs?|figures?|droids?|pieces?|parts?)\b|build only|ship only|vehicle only|incomplete|\b\d{1,2}%\s*complete/i.test(title)) return;
      if (condition === "New/Sealed" && /\b(used|built|assembled|opened|open box|unsealed|new other|no box|without box|pieces only|damaged box|box damage|crushed box|sealed bags)\b/i.test(title)) return;
      if (condition !== "New/Sealed" && /\b(sealed|misb|nib|brand new|new in box)\b/i.test(title)) return;
      if (condition !== "New/Sealed" && !/\b(100%|complete|with (?:mini)?figures|w\/\s*(?:mini)?figs)\b/i.test(title)) return;
      sales.push({ date, title, price: value, url });
    });
  }
  return sales.sort((a, b) => b.date.localeCompare(a.date));
}
export function saleMedian(sales: Sale[], now: number) {
  let selected: Sale[] = [], window = 180;
  for (const days of [7, 30, 90, 180]) {
    const candidates = sales.filter(s => (now - Date.parse(`${s.date}T00:00:00Z`)) / 86400000 <= days);
    if (candidates.length >= 5 || days === 180) { selected = candidates; window = days; break; }
  }
  if (selected.length < 3) throw new Error("Fewer than three recent condition-matched completed sales");
  const centre = median(selected.map(s => s.price)), mad = median(selected.map(s => Math.abs(s.price - centre)));
  const bound = Math.max(3 * 1.4826 * mad, centre * .30);
  const comps = selected.filter(s => Math.abs(s.price - centre) <= bound);
  if (comps.length < 3) throw new Error("Too few completed sales after excluding outliers");
  return { market: Math.round(median(comps.map(s => s.price)) * 100) / 100, comps, windowDays: window, excluded: selected.length - comps.length };
}
function secondary(source: "BrickEconomy" | "BrickPriceWatch", input: Page, number: string, condition: Condition, fetchedAt: string): MarketSource {
  const $ = load(input.html);
  if (!exactNumber(number).test($("h1").first().text())) throw new Error(`${source}: exact-set mismatch`);
  const panel = source === "BrickEconomy" ? $("#ContentPlaceHolder1_PanelSetPricing") : $("body");
  const text = panel.text().replace(/\s+/g, " ").trim();
  const target = source === "BrickEconomy" ? (condition === "New/Sealed" ? /New\/Sealed\s*Value\s*(\$[\d,.]+)/ : /Used\s*Value\s*(\$[\d,.]+)/) : (condition === "New/Sealed" ? /New \/ sealed value\s*(\$[\d,.]+)/ : /Used value\s*(\$[\d,.]+)/);
  let m = text.match(target), observedCondition: string = condition, kind: MarketSource["kind"] = "estimate";
  if (!m) {
    const fallback = source === "BrickEconomy" ? /(?:New\/Sealed\s*Value|Market price)\s*(\$[\d,.]+)/ : /(?:New \/ sealed value|Latest monthly close|Latest estimate)\s*(\$[\d,.]+)/;
    m = text.match(fallback);
    if (!m && source === "BrickEconomy") { m = text.match(/Retail price\s*(\$[\d,.]+)/); kind = "retail"; }
    observedCondition = "New/Sealed";
  }
  if (!m) throw new Error(`${source}: market cross-check unavailable`);
  const value = price(m[1])!;
  const dataAsOf = source === "BrickPriceWatch" ? text.match(/Last market check\s+([^ ]+)/)?.[1] : undefined;
  return { source, label: observedCondition === condition ? "Condition price cross-check" : "Sealed/retail ceiling for context", value, kind, url: input.url, fetchedAt, condition, observedCondition, dataAsOf,
    detail: `${observedCondition === condition ? "Matching-condition secondary estimate" : "Sealed or retail context; not a used-condition valuation"}. ${dataAsOf ? `Source-reported market check: ${dataAsOf}. ` : ""}Completed sales determine the valuation; forecasts and older secondary estimates receive no weight in its median.` };
}

export async function researchMarket(item: ResearchItem) {
  const number = item.setNumber.trim().replace(/-1$/, "");
  if (!/^\d{4,7}$/.test(number)) throw new Error("Invalid set number");
  if (item.condition === "Used Incomplete") throw new Error("Missing-parts profile requires manual condition review");
  const now = Date.now(), fetchedAt = new Date(now).toISOString(), signal=AbortSignal.timeout(42000);
  const previous = item.marketSources?.find(s => /^https:\/\/www\.pricecharting\.com\/game\//.test(s.url || ""))?.url;
  const [pc, be, bpw, bl] = await Promise.allSettled([
    priceCharting(number, previous,signal), page(`https://www.brickeconomy.com/set/${number}-1/`,signal),
    page(`https://brickpricewatch.com/sets/${number}-1`,signal), page(`https://www.bricklink.com/catalogPG.asp?S=${number}-1&colorID=0&viewExclude=Y`,signal),
  ]);
  const requirePage = (result: PromiseSettledResult<Page>) => { if (result.status === "rejected") throw result.reason; return result.value; };
  const pcPage = requirePage(pc), sales = parseSales(pcPage.html, number, item.condition, now), result = saleMedian(sales, now);
  const beSource = secondary("BrickEconomy", requirePage(be), number, item.condition, fetchedAt);
  const bpwSource = secondary("BrickPriceWatch", requirePage(bpw), number, item.condition, fetchedAt);
  if (beSource.kind === "estimate" && beSource.observedCondition === item.condition && (result.market / beSource.value < .5 || result.market / beSource.value > 2)) throw new Error("Sold prices and secondary estimate disagree; review required");
  if (item.currentMarket > 0 && (result.market / item.currentMarket < .25 || result.market / item.currentMarket > 4)) throw new Error("Large price movement requires review");
  const sources: MarketSource[] = [
    { source: "PriceCharting", label: "Exact-set completed sales", kind: "sold", value: result.market, url: pcPage.url, fetchedAt, condition: item.condition, comps: result.comps,
      detail: `Median of ${result.comps.length} ${item.condition} completed sales in ${result.windowDays} days. Mismatched, incomplete, accessory, multiple-set and outlier listings excluded. Shipping and tax excluded where not separately reported.` },
    { source: "eBay completed sales via PriceCharting", label: "Linked completed transactions", kind: "sold", value: result.market, url: result.comps[0].url, fetchedAt, condition: item.condition, comps: result.comps,
      detail: "Transaction prices and dates reported by PriceCharting; this is the same correlated sales evidence, not another independent valuation." },
    beSource, bpwSource,
  ];
  return { ...result, sources, bricklink: bl.status === "fulfilled" ? "Public guide accessible; not used as sole valuation" : "Public guide unavailable; no BrickLink price asserted" };
}
