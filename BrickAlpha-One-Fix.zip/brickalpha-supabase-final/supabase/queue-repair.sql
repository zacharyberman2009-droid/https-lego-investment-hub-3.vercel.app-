create table if not exists public.price_refresh_jobs (
  inventory_id text primary key references public.inventory_items(id) on delete cascade,
  owner_id uuid not null,
  requested_at timestamptz,
  status text not null default 'pending' check(status in ('pending','running','needs_review','complete')),
  attempted_at timestamptz,
  lease_until timestamptz,
  attempts integer not null default 0,
  error text,
  result jsonb,
  updated_at timestamptz not null default now()
);
alter table public.price_refresh_jobs enable row level security;
grant select, insert, update on public.price_refresh_jobs to authenticated;
create policy refresh_jobs_select on public.price_refresh_jobs for select to authenticated
  using (owner_id = (select auth.uid()) or owner_id = (select public.brickalpha_collection_owner()));
create policy refresh_jobs_insert on public.price_refresh_jobs for insert to authenticated
  with check (owner_id = (select auth.uid()) or owner_id = (select public.brickalpha_collection_owner()));
create policy refresh_jobs_update on public.price_refresh_jobs for update to authenticated
  using (owner_id = (select auth.uid()) or owner_id = (select public.brickalpha_collection_owner()))
  with check (owner_id = (select auth.uid()) or owner_id = (select public.brickalpha_collection_owner()));
create index price_refresh_jobs_owner_status on public.price_refresh_jobs(owner_id,status);
create or replace function public.claim_price_refresh(p_limit integer default 2, p_retry boolean default false, p_owner_id uuid default null)
returns jsonb language plpgsql set search_path = '' as $claim$
declare
  v_owner uuid := coalesce(public.brickalpha_collection_owner(), auth.uid());
  v_row public.inventory_items%rowtype;
  v_items jsonb := '[]'::jsonb;
  v_now timestamptz := clock_timestamp();
begin
  if v_owner is null and current_user in ('postgres','service_role') then v_owner := p_owner_id; end if;
  if v_owner is null or (p_owner_id is not null and p_owner_id <> v_owner) then
    raise exception using errcode='42501', message='Owner authentication required';
  end if;
  if p_retry then
    update public.price_refresh_jobs set status='pending',error=null,lease_until=null,updated_at=v_now
      where owner_id=v_owner and status='needs_review';
  end if;
  for v_row in
    select i.* from public.inventory_items i
    left join public.price_refresh_jobs j on j.inventory_id=i.id and j.owner_id=i.owner_id
    where i.owner_id=v_owner and i.refresh_requested
      and (j.inventory_id is null or j.requested_at is distinct from i.refresh_requested_at
           or j.status='pending' or (j.status='running' and j.lease_until < v_now))
    order by case when btrim(split_part(i.set_number,'-',1)) ~ '^[0-9]+$'
             then btrim(split_part(i.set_number,'-',1))::bigint else 999999999 end,
             i.set_number,i.condition,i.id
    limit least(8,greatest(1,coalesce(p_limit,2)))
    for update of i skip locked
  loop
    insert into public.price_refresh_jobs(inventory_id,owner_id,requested_at,status,lease_until,attempts,updated_at)
      values(v_row.id,v_owner,v_row.refresh_requested_at,'running',v_now+interval '3 minutes',1,v_now)
      on conflict(inventory_id) do update set
        requested_at=excluded.requested_at,status='running',lease_until=excluded.lease_until,
        attempts=public.price_refresh_jobs.attempts+1,error=null,updated_at=v_now;
    v_items := v_items || jsonb_build_array(jsonb_build_object(
      'id',v_row.id,'setNumber',v_row.set_number,'name',v_row.name,
      'condition',v_row.condition,'currentMarket',v_row.market,
      'marketSources',v_row.market_sources,'notes',v_row.notes,
      'requestedAt',v_row.refresh_requested_at,'version',md5(to_jsonb(v_row)::text)
    ));
  end loop;
  return jsonb_build_object('ok',true,'items',v_items);
end;
$claim$;
revoke all on function public.claim_price_refresh(integer,boolean,uuid) from public,anon;
grant execute on function public.claim_price_refresh(integer,boolean,uuid) to authenticated,service_role;

CREATE OR REPLACE FUNCTION public.brick_alpha_queue(p_action text DEFAULT 'status'::text, p_payload jsonb DEFAULT '{}'::jsonb, p_owner_id uuid DEFAULT NULL::uuid)
 RETURNS jsonb
 LANGUAGE plpgsql
 SET search_path TO ''
AS $function$
declare
  v_owner uuid := coalesce(public.brickalpha_collection_owner(), auth.uid());
  v_action text := p_action;
  v_item public.inventory_items%rowtype;
  v_market numeric;
  v_sources jsonb;
  v_source jsonb;
  v_total bigint;
  v_queued bigint;
  v_jobs jsonb;
  v_now timestamptz := clock_timestamp();
begin
  if v_owner is null and current_user in ('postgres', 'service_role') then
    v_owner := p_owner_id;
  end if;
  if v_owner is null or (p_owner_id is not null and p_owner_id <> v_owner) then
    raise exception using errcode = '42501', message = 'Owner authentication required';
  end if;
  if p_payload is null or jsonb_typeof(p_payload) <> 'object' then
    raise exception using errcode = '22023', message = 'Payload must be a JSON object';
  end if;
  if v_action not in ('status', 'next', 'run', 'queue-all', 'queue-and-run', 'complete') or v_action is null then
    raise exception using errcode = '22023', message = 'Unsupported queue action';
  end if;

  if v_action in ('queue-all', 'queue-and-run') then
    update public.inventory_items set refresh_requested = true, refresh_requested_at = v_now
      where owner_id = v_owner and refresh_requested = false;
  end if;

  if v_action = 'complete' then
    select * into v_item from public.inventory_items
      where id = p_payload->>'id' and owner_id = v_owner for update;
    if not found then
      raise exception using errcode = '22023', message = 'Queued item not found';
    end if;
    if not v_item.refresh_requested or
       (p_payload->>'version') is distinct from md5(to_jsonb(v_item)::text) then
      raise exception using errcode = '40001', message = 'Item changed or was already completed; reload it before saving';
    end if;
    if (p_payload->>'condition') is distinct from v_item.condition then
      raise exception using errcode = '22023', message = 'Research condition must exactly match the inventory condition';
    end if;
    if jsonb_typeof(p_payload->'market') is distinct from 'number' then
      raise exception using errcode = '22023', message = 'A numeric market value is required';
    end if;
    v_market := round((p_payload->>'market')::numeric, 2);
    if v_market <= 0 or v_market > 100000 then
      raise exception using errcode = '22023', message = 'Invalid market value; prior price preserved';
    end if;
    if v_item.market > 0 and (v_market > v_item.market * 4 or v_market < v_item.market * 0.25) then
      raise exception using errcode = '22023', message = 'Suspicious price movement; prior price and queue preserved';
    end if;
    v_sources := p_payload->'sources';
    if jsonb_typeof(v_sources) is distinct from 'array' then
      raise exception using errcode = '22023', message = 'Supporting research sources are required';
    end if;
    if jsonb_array_length(v_sources) = 0 or jsonb_array_length(v_sources) > 50 then
      raise exception using errcode = '22023', message = 'Supply between 1 and 50 supporting sources';
    end if;
    for v_source in select value from jsonb_array_elements(v_sources) loop
      if jsonb_typeof(v_source) is distinct from 'object' or
         nullif(btrim(v_source->>'source'), '') is null or
         coalesce(v_source->>'url', '') !~ '^https://[a-zA-Z0-9.-]+/' or
         (v_source->>'condition') is distinct from v_item.condition then
        raise exception using errcode = '22023', message = 'Each source needs a source name, evidence URL, and matching condition';
      end if;
      if (v_source->>'url') ~* '^https://([^/]*\.)?(amazon\.[^/]+|stockx\.com)(/|$)' or
         concat_ws(' ', v_source->>'kind', v_source->>'source') ~* 'part[ _-]*out' then
        raise exception using errcode = '22023', message = 'Excluded valuation source';
      end if;
    end loop;

    -- Both writes share this transaction. History failure cannot clear a job.
    -- Daily uniqueness is already part of the existing history schema.
    insert into public.price_history (inventory_id, owner_id, price_date, market)
      values (v_item.id, v_owner, (v_now at time zone 'UTC')::date, v_market)
      on conflict (inventory_id, price_date) do update set market = excluded.market
      where public.price_history.owner_id = excluded.owner_id;
    if not found then
      raise exception using errcode = '42501', message = 'History owner mismatch';
    end if;
    update public.inventory_items set
      market = v_market, market_sources = v_sources, last_updated = v_now,
      refresh_requested = false
      where id = v_item.id and owner_id = v_owner;
    update public.price_refresh_jobs set status = 'complete', lease_until = null,
      attempted_at = v_now, error = null, result = p_payload - 'version', updated_at = v_now
      where inventory_id = v_item.id and owner_id = v_owner;
    return jsonb_build_object('ok', true, 'processed', 1, 'id', v_item.id, 'market', v_market);
  end if;

  select count(*), count(*) filter (where refresh_requested) into v_total, v_queued
    from public.inventory_items where owner_id = v_owner;
  if v_action in ('next', 'run', 'queue-and-run') then
    select coalesce(jsonb_agg(job), '[]'::jsonb) into v_jobs from (
      select jsonb_build_object(
        'id', i.id, 'setNumber', i.set_number, 'name', i.name,
        'condition', i.condition, 'currentMarket', i.market,
        'lastUpdated', i.last_updated, 'requestedAt', i.refresh_requested_at,
        'version', md5(to_jsonb(i)::text)
      ) as job from public.inventory_items i
      where i.owner_id = v_owner and i.refresh_requested
      order by case when btrim(split_part(i.set_number, '-', 1)) ~ '^[0-9]+$' then btrim(split_part(i.set_number, '-', 1))::bigint else 999999999 end, i.set_number, i.condition, i.id
      limit least(500, greatest(1, coalesce((p_payload->>'limit')::int, 100)))
    ) pending;
  end if;
  return jsonb_build_object(
    'ok', true, 'mode', 'chatgpt-managed', 'total', v_total, 'queued', v_queued,
    'processed', 0, 'status', case when v_queued = 0 then 'complete' else 'awaiting_research' end,
    'items', coalesce(v_jobs, '[]'::jsonb)
  );
end;
$function$;

CREATE OR REPLACE FUNCTION public.complete_price_refresh(p_id text, p_market numeric, p_sources jsonb DEFAULT '[]'::jsonb)
 RETURNS TABLE(item_id text, item_set_number text, item_market numeric, item_last_updated timestamp with time zone)
 LANGUAGE plpgsql
 SET search_path TO 'public'
AS $function$
declare
  v_user uuid := coalesce(public.brickalpha_collection_owner(), auth.uid());
  v_now timestamptz := now();
  v_set_number text;
begin
  if v_user is null then
    raise exception 'Not authenticated';
  end if;
  if p_market is null or p_market < 0 or p_market > 1000000 then
    raise exception 'Invalid market value';
  end if;
  if not public.has_four_viable_market_sources(p_sources) then
    raise exception 'At least 4 distinct viable market-source domains with URLs are required before completing a refresh';
  end if;

  update public.inventory_items
  set market = p_market,
      market_sources = coalesce(p_sources, '[]'::jsonb),
      last_updated = v_now,
      refresh_requested = false,
      refresh_requested_at = null,
      updated_at = v_now
  where id = p_id
    and owner_id = v_user
  returning set_number into v_set_number;

  if not found then
    raise exception 'Inventory item not found';
  end if;

  insert into public.price_history(inventory_id, price_date, market, owner_id)
  values (p_id, v_now::date, p_market, v_user)
  on conflict (inventory_id, price_date)
  do update set market = excluded.market, owner_id = excluded.owner_id;

  return query select p_id, v_set_number, p_market, v_now;
end;
$function$;

