-- A real server scheduler: no browser session, paid pricing API, or client-side secret required.
create extension if not exists pg_cron;
create extension if not exists pg_net with schema extensions;
create table if not exists brickalpha_private.worker_state(
 id boolean primary key default true check(id),enabled boolean not null default false,
 last_started_at timestamptz,last_finished_at timestamptz,last_error text,last_request_id bigint
);
alter table brickalpha_private.worker_state enable row level security;
revoke all on brickalpha_private.worker_state from public,anon,authenticated;
insert into brickalpha_private.worker_state(id) values(true) on conflict(id) do nothing;
do $$ begin
 if not exists(select 1 from vault.secrets where name='brickalpha_worker_secret') then
   perform vault.create_secret(encode(extensions.gen_random_bytes(32),'hex'),'brickalpha_worker_secret');
 end if;
end $$;

create or replace function brickalpha_private.worker_authorized(p_secret text)
returns boolean language plpgsql security definer set search_path='' as $$
begin
 if auth.uid() is not null or (session_user<>'postgres' and coalesce(auth.jwt()->>'role','')<>'service_role') then raise exception 'Worker service access required'; end if;
 return length(p_secret)=64 and exists(select 1 from vault.decrypted_secrets where name='brickalpha_worker_secret' and decrypted_secret=p_secret);
end $$;
create or replace function public.brickalpha_worker_authorize(p_secret text)
returns boolean language sql security invoker set search_path='' as $$select brickalpha_private.worker_authorized(p_secret)$$;

create or replace function brickalpha_private.wake_worker(p_dry_run boolean default false)
returns bigint language plpgsql security definer set search_path='' as $$
declare v_request bigint; v_secret text; v_enabled boolean; v_started timestamptz; v_finished timestamptz;
begin
 if auth.uid() is not null or (session_user<>'postgres' and coalesce(auth.jwt()->>'role','')<>'service_role') then raise exception 'Worker service access required'; end if;
 select enabled,last_started_at,last_finished_at into v_enabled,v_started,v_finished from brickalpha_private.worker_state where id=true for update;
 if not p_dry_run and not v_enabled then return null; end if;
 -- Only one scheduled batch may be outstanding. Recover a lost HTTP request after two minutes.
 if not p_dry_run and v_started is not null and (v_finished is null or v_started>v_finished) and v_started>clock_timestamp()-interval '2 minutes' then return null; end if;
 if not p_dry_run and not exists(
   select 1 from public.inventory_items i left join public.price_refresh_jobs j on j.inventory_id=i.id and j.owner_id=i.owner_id
   where i.refresh_requested and (j.inventory_id is null or j.requested_at is distinct from i.refresh_requested_at or j.status='pending' and (j.next_attempt_at is null or j.next_attempt_at<=clock_timestamp()) or j.status='running' and (j.lease_until is null or j.lease_until<=clock_timestamp()))
 ) then return null; end if;
 select decrypted_secret into v_secret from vault.decrypted_secrets where name='brickalpha_worker_secret';
 if v_secret is null then raise exception 'Worker secret missing'; end if;
 select net.http_post(
   url:='https://nhxprfrnjsbdqisbdgvh.supabase.co/functions/v1/brickalpha-worker',
   headers:=jsonb_build_object('Content-Type','application/json','x-brickalpha-worker-secret',v_secret),
   body:=jsonb_build_object('dryRun',p_dry_run),timeout_milliseconds:=60000
 ) into v_request;
 update brickalpha_private.worker_state set last_started_at=clock_timestamp(),last_request_id=v_request where id=true;
 return v_request;
end $$;
create or replace function public.brickalpha_wake_worker(p_dry_run boolean default false)
returns bigint language sql security invoker set search_path='' as $$select brickalpha_private.wake_worker(p_dry_run)$$;
create or replace function brickalpha_private.worker_record(p_error text default null)
returns void language plpgsql security definer set search_path='' as $$
begin
 if auth.uid() is not null or (session_user<>'postgres' and coalesce(auth.jwt()->>'role','')<>'service_role') then raise exception 'Worker service access required'; end if;
 update brickalpha_private.worker_state set last_finished_at=clock_timestamp(),last_error=left(p_error,1000) where id=true;
end $$;
create or replace function public.brickalpha_worker_record(p_error text default null)
returns void language sql security invoker set search_path='' as $$select brickalpha_private.worker_record(p_error)$$;

-- Private privileged helpers only expose secret verification, a fixed worker URL and a status write.
revoke all on function brickalpha_private.worker_authorized(text),brickalpha_private.wake_worker(boolean),brickalpha_private.worker_record(text) from public,anon,authenticated;
grant usage on schema brickalpha_private to service_role;
grant execute on function brickalpha_private.worker_authorized(text),brickalpha_private.wake_worker(boolean),brickalpha_private.worker_record(text) to service_role;
revoke all on function public.brickalpha_worker_authorize(text),public.brickalpha_wake_worker(boolean),public.brickalpha_worker_record(text) from public,anon,authenticated;
grant execute on function public.brickalpha_worker_authorize(text),public.brickalpha_wake_worker(boolean),public.brickalpha_worker_record(text) to service_role;
-- Minute checks do no HTTP work while idle. The hourly requirement is exceeded; only existing explicit requests are processed.
select cron.schedule('brickalpha-explicit-queue','* * * * *',$job$select brickalpha_private.wake_worker(false);$job$);
