-- Run after consolidated-repair.sql inside BEGIN ... ROLLBACK. All fixtures roll back.
do $$
declare v_user uuid; v_owner uuid; v_id text:='__brickalpha_repair_test_'||gen_random_uuid(); v_other text:=v_id||'_b'; v_row public.inventory_items%rowtype; v_original text; v_claim jsonb; v_second jsonb; v_token text; v_result jsonb; v_sources jsonb; v_rejected boolean; v_request timestamptz; v_price numeric;
begin
 select a.user_id,a.owner_id into v_user,v_owner from brickalpha_private.collection_access a join auth.users u on u.id=a.user_id where u.is_anonymous=false and u.email_confirmed_at is not null and exists(select 1 from public.inventory_items i where i.owner_id=a.owner_id) limit 1;
 if v_user is null then raise exception 'Linked confirmed account missing'; end if;
 perform set_config('request.jwt.claims',jsonb_build_object('sub',v_user,'role','authenticated','is_anonymous',false)::text,true);
 set local role authenticated;
 if public.brickalpha_require_owner()<>v_owner then raise exception 'Wrong collection owner'; end if;
 v_result:=public.brickalpha_inventory();
 if jsonb_array_length(v_result->'items')<>(select count(*) from public.inventory_items where owner_id=v_owner) or jsonb_array_length(v_result->'history')<>(select count(*) from public.price_history where owner_id=v_owner) then raise exception 'Inventory or history incomplete'; end if;
 v_rejected:=false;
 begin perform public.brickalpha_require_owner(gen_random_uuid()); exception when insufficient_privilege then v_rejected:=true; end;
 if not v_rejected then raise exception 'Cross-owner access allowed'; end if;
 perform public.brickalpha_save_inventory(v_id,jsonb_build_object('set_number','0001','name','REPAIR TEST A','condition','New/Sealed','quantity',2,'cost',50,'market',100,'store_price',125,'status','Hold','location','test','notes','test'),true);
 perform public.brickalpha_save_inventory(v_other,jsonb_build_object('set_number','0002','name','REPAIR TEST B','market',100),true);
 -- Ordinary old-client writes cannot queue anything.
 update public.inventory_items set refresh_requested=true,refresh_requested_at=clock_timestamp() where id=v_id;
 if (select refresh_requested from public.inventory_items where id=v_id) then raise exception 'Legacy automatic queuing still works'; end if;
 v_result:=public.brickalpha_request_refresh(array[]::text[]);
 if (v_result->>'queued')::int<>0 then raise exception 'Empty selection queued data'; end if;
 perform public.brickalpha_request_refresh(array[v_id,v_other]);
 select * into v_row from public.inventory_items where id=v_id;
 v_original:=public.brickalpha_inventory_version(v_row);
 v_claim:=public.claim_price_refresh(1,false);
 if v_claim->'items'->0->>'id'<>v_id then raise exception 'Numeric set ordering incorrect'; end if;
 v_second:=public.claim_price_refresh(1,false);
 if v_second->'items'->0->>'id'<>v_other then raise exception 'Duplicate concurrent claim'; end if;
 v_token:=v_claim->'items'->0->>'leaseToken';
 v_sources:=jsonb_build_array(
 jsonb_build_object('source','Fixture sold','kind','sold','condition','New/Sealed','url','https://www.pricecharting.com/game/fixture'),
 jsonb_build_object('source','Fixture correlated sold','kind','sold','condition','New/Sealed','url','https://www.ebay.com/itm/100'),
 jsonb_build_object('source','Fixture estimate','kind','estimate','condition','New/Sealed','url','https://www.brickeconomy.com/set/0001-1/'),
 jsonb_build_object('source','Fixture reference','kind','estimate','condition','New/Sealed','url','https://brickpricewatch.com/sets/0001-1'));
 v_rejected:=false;
 begin perform public.brick_alpha_queue('complete',jsonb_build_object('id',v_id,'version',v_claim->'items'->0->>'version','condition','New/Sealed','market',0,'sources',v_sources,'leaseToken',v_token)); exception when others then v_rejected:=true; end;
 if not v_rejected then raise exception 'Zero price accepted'; end if;
 v_rejected:=false;
 begin perform public.brick_alpha_queue('complete',jsonb_build_object('id',v_id,'version',v_claim->'items'->0->>'version','condition','Used Complete','market',110,'sources',v_sources,'leaseToken',v_token)); exception when others then v_rejected:=true; end;
 if not v_rejected then raise exception 'Condition mismatch accepted'; end if;
 perform public.brick_alpha_queue('complete',jsonb_build_object('id',v_id,'version',v_claim->'items'->0->>'version','condition','New/Sealed','market',110,'sources',v_sources,'leaseToken',v_token));
 if (select market from public.price_history where inventory_id=v_id and price_date=(clock_timestamp() at time zone 'UTC')::date)<>110 or (select refresh_requested from public.inventory_items where id=v_id) or (select status from public.price_refresh_jobs where inventory_id=v_id)<>'complete' then raise exception 'Atomic completion failed'; end if;
 -- A form opened before research can still save a name without replaying the old price or history.
 perform public.brickalpha_save_inventory(v_id,jsonb_build_object('name','Edited name'),false,v_original,100);
 select market into v_price from public.inventory_items where id=v_id;
 if v_price<>110 then raise exception 'Stale edit overwrote refreshed price'; end if;
 v_rejected:=false;
 begin perform public.brickalpha_save_inventory(v_id,jsonb_build_object('quantity',3),false,v_original,100); exception when serialization_failure then v_rejected:=true; end;
 if not v_rejected then raise exception 'Lost edit protection failed'; end if;
 -- A fresh explicit request replaces the generation, so a late failure cannot demote it.
 v_request:=(v_second->'items'->0->>'requestedAt')::timestamptz;
 perform public.brickalpha_request_refresh(array[v_other]);
 v_result:=public.brickalpha_finish_attempt(v_other,v_request,(v_second->'items'->0->>'leaseToken')::uuid,'late failure',false);
 if (v_result->>'recorded')::boolean or (select status from public.price_refresh_jobs where inventory_id=v_other)<>'pending' then raise exception 'Late attempt changed a replacement request'; end if;
 -- Repeat reads cannot enqueue data, and metadata remains unchanged by pricing.
 perform public.brickalpha_inventory(); perform public.brickalpha_inventory();
 if (select refresh_requested from public.inventory_items where id=v_id) then raise exception 'Read requeued an item'; end if;
 if (select quantity<>2 or cost<>50 or store_price<>125 or status<>'Hold' or location<>'test' or notes<>'test' or owner_id<>v_owner from public.inventory_items where id=v_id) then raise exception 'Protected fields changed'; end if;
 reset role;
end $$;
select 'PASS: owner mapping, RLS isolation, complete inventory/history, read-only loads, explicit scope, numeric order, lease isolation, zero rejection, exact condition, atomic completion, stale edit protection and late-worker protection' as result;
