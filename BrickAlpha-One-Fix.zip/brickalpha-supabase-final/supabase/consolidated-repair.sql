-- Brick Alpha consolidated repair. Additive: no inventory reset, import, owner reassignment or repricing.
alter table public.price_refresh_jobs add column if not exists lease_token uuid;
alter table public.price_refresh_jobs add column if not exists next_attempt_at timestamptz;
create index if not exists inventory_refresh_owner on public.inventory_items(owner_id) where refresh_requested;

create or replace function public.brickalpha_require_owner(p_owner_id uuid default null)
returns uuid language plpgsql stable security invoker set search_path='' as $$
declare v_owner uuid;
begin
  if auth.uid() is null and current_user in ('postgres','service_role') then
    v_owner:=p_owner_id;
  else
    v_owner:=public.brickalpha_collection_owner();
  end if;
  if v_owner is null or (p_owner_id is not null and p_owner_id<>v_owner) then
    raise exception using errcode='42501', message='Sign in with the account linked to your Brick Alpha collection.';
  end if;
  if not exists(select 1 from public.inventory_items where owner_id=v_owner)
     and coalesce((auth.jwt()->>'is_anonymous')::boolean,false) then
    raise exception using errcode='42501', message='This anonymous session has no collection. Sign in with your linked email.';
  end if;
  return v_owner;
end $$;

create or replace function public.brickalpha_inventory_version(p_row public.inventory_items)
returns text language sql immutable security invoker set search_path='' as $$
 select md5((to_jsonb(p_row)-array['market','market_sources','last_updated','refresh_requested','refresh_requested_at','updated_at'])::text)
$$;

create or replace function public.brickalpha_inventory()
returns jsonb language plpgsql stable security invoker set search_path='' as $$
declare v_owner uuid:=public.brickalpha_require_owner(); v_items jsonb; v_history jsonb;
begin
 select coalesce(jsonb_agg(to_jsonb(i)||jsonb_build_object(
   'record_version',public.brickalpha_inventory_version(i),
   'queue_status',case when i.refresh_requested then case when j.requested_at is not distinct from i.refresh_requested_at then coalesce(j.status,'pending') else 'pending' end else 'complete' end,
   'queue_error',case when i.refresh_requested and j.requested_at is not distinct from i.refresh_requested_at then j.error end
 ) order by i.created_at desc,i.id),'[]'::jsonb) into v_items
 from public.inventory_items i left join public.price_refresh_jobs j on j.inventory_id=i.id and j.owner_id=i.owner_id where i.owner_id=v_owner;
 select coalesce(jsonb_agg(jsonb_build_object('inventory_id',inventory_id,'price_date',price_date,'market',market) order by price_date,id),'[]'::jsonb)
 into v_history from public.price_history where owner_id=v_owner;
 return jsonb_build_object('owner_id',v_owner,'items',v_items,'history',v_history);
end $$;

create or replace function public.brickalpha_save_inventory(p_id text,p_patch jsonb,p_new boolean default false,p_expected_version text default null,p_expected_market numeric default null)
returns jsonb language plpgsql security invoker set search_path='' as $$
declare v_owner uuid:=public.brickalpha_require_owner(); v_old public.inventory_items%rowtype; v_next public.inventory_items%rowtype; v_now timestamptz:=clock_timestamp(); v_price_changed boolean;
begin
 if p_id is null or length(p_id)>200 or jsonb_typeof(p_patch) is distinct from 'object' then raise exception 'Invalid inventory input'; end if;
 if exists(select 1 from jsonb_object_keys(p_patch) k where k<>all(array['set_number','name','theme','year','condition','quantity','cost','market','store_price','status','location','notes','image_url'])) then raise exception 'Only editable inventory fields may be saved'; end if;
 select * into v_old from public.inventory_items where id=p_id and owner_id=v_owner for update;
 if p_new then
   if found then raise exception 'This inventory ID already exists. Reload before saving.'; end if;
   select * into v_next from jsonb_populate_record(null::public.inventory_items,jsonb_build_object('id',p_id,'owner_id',v_owner,'quantity',1,'cost',0,'market',0,'store_price',0,'status','For Sale','condition','New/Sealed','created_at',v_now,'updated_at',v_now,'refresh_requested',false)||p_patch);
 else
   if not found then raise exception 'Inventory entry not found for your collection'; end if;
   if p_expected_version is distinct from public.brickalpha_inventory_version(v_old) then raise exception using errcode='40001',message='This entry was edited elsewhere. Reload it before saving.'; end if;
   if p_patch?'market' and p_expected_market is distinct from v_old.market then raise exception using errcode='40001',message='The market price changed while this form was open. Reload before editing the price.'; end if;
   select * into v_next from jsonb_populate_record(v_old,p_patch);
 end if;
 if nullif(btrim(v_next.set_number),'') is null or nullif(btrim(v_next.name),'') is null or v_next.condition not in ('New/Sealed','Used Complete','Used Incomplete') or v_next.status not in ('For Sale','Hold','Personal','Consignment') then raise exception 'A set number, name, valid condition and status are required'; end if;
 if v_next.quantity is null or v_next.quantity<1 or v_next.quantity>100000 or v_next.cost is null or v_next.cost<0 or v_next.cost='NaN'::numeric or v_next.store_price is null or v_next.store_price<0 or v_next.store_price='NaN'::numeric or v_next.market is null or v_next.market<0 or v_next.market>100000 or v_next.market='NaN'::numeric then raise exception 'Quantity and prices must be valid nonnegative numbers'; end if;
 if not p_new and v_old.market>0 and v_next.market<=0 then raise exception 'A valid saved market value cannot be replaced by zero'; end if;
 v_price_changed:=p_new and v_next.market>0 or not p_new and v_next.market is distinct from v_old.market;
 if v_price_changed then
   v_next.market_sources:=jsonb_build_array(jsonb_build_object('source','Manual entry','kind','manual','value',v_next.market,'condition',v_next.condition,'fetchedAt',v_now));
   v_next.last_updated:=null;
 end if;
 perform set_config('brickalpha.price_action','manual',true);
 if p_new then
   insert into public.inventory_items(id,owner_id,set_number,name,theme,year,condition,quantity,cost,market,store_price,status,location,notes,image_url,market_sources,last_updated,created_at,updated_at,refresh_requested)
   values(p_id,v_owner,v_next.set_number,v_next.name,v_next.theme,v_next.year,v_next.condition,v_next.quantity,v_next.cost,v_next.market,v_next.store_price,v_next.status,v_next.location,v_next.notes,v_next.image_url,coalesce(v_next.market_sources,'[]'),null,v_now,v_now,false);
 else
   update public.inventory_items set set_number=v_next.set_number,name=v_next.name,theme=v_next.theme,year=v_next.year,condition=v_next.condition,quantity=v_next.quantity,cost=v_next.cost,market=v_next.market,store_price=v_next.store_price,status=v_next.status,location=v_next.location,notes=v_next.notes,image_url=v_next.image_url,market_sources=v_next.market_sources,last_updated=case when v_next.set_number is distinct from v_old.set_number or v_next.condition is distinct from v_old.condition then null else v_next.last_updated end,updated_at=v_now where id=p_id and owner_id=v_owner;
 end if;
 if v_price_changed then
   insert into public.price_history(inventory_id,owner_id,price_date,market) values(p_id,v_owner,(v_now at time zone 'UTC')::date,v_next.market)
   on conflict(inventory_id,price_date) do update set market=excluded.market where public.price_history.owner_id=excluded.owner_id;
   if not found then raise exception 'History ownership mismatch'; end if;
 end if;
 perform set_config('brickalpha.price_action','',true);
 return jsonb_build_object('ok',true,'id',p_id);
end $$;

-- Legacy page loads and stale forms cannot change queue state by PATCH/upsert.
create or replace function public.preserve_refresh_requested_at()
returns trigger language plpgsql security invoker set search_path='' as $$
declare v_action text:=coalesce(current_setting('brickalpha.queue_action',true),'');
begin
 if tg_op='INSERT' then
   new.refresh_requested:=false; new.refresh_requested_at:=null;
 elsif v_action='explicit' then
   if new.refresh_requested then new.refresh_requested_at:=coalesce(new.refresh_requested_at,clock_timestamp()); end if;
 elsif v_action='complete' then
   if new.refresh_requested=false then new.refresh_requested_at:=null; end if;
 else
   new.refresh_requested:=old.refresh_requested; new.refresh_requested_at:=old.refresh_requested_at;
 end if;
 return new;
end $$;
drop trigger if exists inventory_preserve_refresh_requested_at on public.inventory_items;
create trigger inventory_preserve_refresh_requested_at before insert or update of refresh_requested,refresh_requested_at on public.inventory_items for each row execute function public.preserve_refresh_requested_at();

create or replace function public.brickalpha_request_refresh(p_ids text[] default null,p_owner_id uuid default null)
returns jsonb language plpgsql security invoker set search_path='' as $$
declare v_owner uuid:=public.brickalpha_require_owner(p_owner_id); v_now timestamptz:=clock_timestamp(); v_count integer; v_previous text:=coalesce(current_setting('brickalpha.queue_action',true),'');
begin
 if p_ids is not null and cardinality(p_ids)=0 then return jsonb_build_object('ok',true,'queued',0); end if;
 perform set_config('brickalpha.queue_action','explicit',true);
 with requested as (
   update public.inventory_items set refresh_requested=true,refresh_requested_at=v_now
   where owner_id=v_owner and (p_ids is null or id=any(p_ids)) returning id,owner_id,refresh_requested_at
 ) insert into public.price_refresh_jobs(inventory_id,owner_id,requested_at,status,attempts,error,result,lease_until,lease_token,next_attempt_at,updated_at)
 select id,owner_id,refresh_requested_at,'pending',0,null,null,null,null,null,v_now from requested
 on conflict(inventory_id) do update set requested_at=excluded.requested_at,status='pending',attempts=0,error=null,result=null,lease_until=null,lease_token=null,next_attempt_at=null,updated_at=v_now;
 get diagnostics v_count=row_count;
 perform set_config('brickalpha.queue_action',v_previous,true);
 return jsonb_build_object('ok',true,'queued',v_count);
end $$;

create or replace function public.claim_price_refresh(p_limit integer default 2,p_retry boolean default false,p_owner_id uuid default null)
returns jsonb language plpgsql security invoker set search_path='' as $$
declare v_owner uuid:=public.brickalpha_require_owner(p_owner_id); v_row public.inventory_items%rowtype; v_items jsonb:='[]'; v_now timestamptz:=clock_timestamp(); v_token uuid;
begin
 if p_retry then
   update public.price_refresh_jobs j set status='pending',error=null,attempts=0,lease_until=null,lease_token=null,next_attempt_at=null,updated_at=v_now
   where j.owner_id=v_owner and j.status='needs_review' and exists(select 1 from public.inventory_items i where i.id=j.inventory_id and i.owner_id=v_owner and i.refresh_requested and i.refresh_requested_at is not distinct from j.requested_at);
 end if;
 for v_row in
   select i.* from public.inventory_items i left join public.price_refresh_jobs j on j.inventory_id=i.id and j.owner_id=i.owner_id
   where i.owner_id=v_owner and i.refresh_requested and (
     j.inventory_id is null or j.requested_at is distinct from i.refresh_requested_at or
     j.status='pending' and (j.next_attempt_at is null or j.next_attempt_at<=v_now) or
     j.status='running' and (j.lease_until is null or j.lease_until<v_now)
   ) order by case when split_part(btrim(i.set_number),'-',1)~'^[0-9]{1,12}$' then split_part(btrim(i.set_number),'-',1)::bigint else 9999999999999 end,i.set_number,i.condition,i.id
   limit least(8,greatest(1,coalesce(p_limit,2))) for update of i skip locked
 loop
   v_token:=gen_random_uuid();
   insert into public.price_refresh_jobs(inventory_id,owner_id,requested_at,status,lease_until,lease_token,attempts,error,result,next_attempt_at,updated_at)
   values(v_row.id,v_owner,v_row.refresh_requested_at,'running',v_now+interval '3 minutes',v_token,1,null,null,null,v_now)
   on conflict(inventory_id) do update set requested_at=excluded.requested_at,status='running',lease_until=excluded.lease_until,lease_token=excluded.lease_token,attempts=case when public.price_refresh_jobs.requested_at is not distinct from excluded.requested_at then public.price_refresh_jobs.attempts+1 else 1 end,error=null,result=null,next_attempt_at=null,updated_at=v_now;
   v_items:=v_items||jsonb_build_array(jsonb_build_object('id',v_row.id,'setNumber',v_row.set_number,'name',v_row.name,'condition',v_row.condition,'currentMarket',v_row.market,'marketSources',v_row.market_sources,'notes',v_row.notes,'requestedAt',v_row.refresh_requested_at,'leaseToken',v_token,'version',md5(to_jsonb(v_row)::text)));
 end loop;
 return jsonb_build_object('ok',true,'items',v_items);
end $$;

create or replace function public.brickalpha_finish_attempt(p_id text,p_requested_at timestamptz,p_lease_token uuid,p_error text,p_transient boolean default false,p_owner_id uuid default null)
returns jsonb language plpgsql security invoker set search_path='' as $$
declare v_owner uuid:=public.brickalpha_require_owner(p_owner_id); v_count integer;
begin
 update public.price_refresh_jobs j set status=case when p_transient and j.attempts<3 then 'pending' else 'needs_review' end,error=left(p_error,1000),attempted_at=clock_timestamp(),lease_until=null,lease_token=null,next_attempt_at=case when p_transient and j.attempts<3 then clock_timestamp()+interval '15 minutes'*j.attempts else null end,updated_at=clock_timestamp()
 where j.inventory_id=p_id and j.owner_id=v_owner and j.status='running' and j.lease_token=p_lease_token and j.requested_at is not distinct from p_requested_at
 and exists(select 1 from public.inventory_items i where i.id=j.inventory_id and i.owner_id=v_owner and i.refresh_requested and i.refresh_requested_at is not distinct from p_requested_at);
 get diagnostics v_count=row_count;
 return jsonb_build_object('ok',true,'recorded',v_count=1);
end $$;

create or replace function public.brick_alpha_queue(p_action text default 'status',p_payload jsonb default '{}',p_owner_id uuid default null)
returns jsonb language plpgsql security invoker set search_path='' as $$
declare v_owner uuid:=public.brickalpha_require_owner(p_owner_id); v_item public.inventory_items%rowtype; v_job public.price_refresh_jobs%rowtype; v_market numeric; v_sources jsonb; v_source jsonb; v_now timestamptz:=clock_timestamp(); v_previous text:=coalesce(current_setting('brickalpha.queue_action',true),''); v_items jsonb:='[]'; v_attempts jsonb; v_total bigint; v_queued bigint; v_ready bigint; v_running bigint; v_review bigint; v_waiting bigint;
begin
 if p_payload is null or jsonb_typeof(p_payload)<>'object' then raise exception 'Payload must be an object'; end if;
 if p_action is null or p_action not in ('status','next','run','queue-all','queue-and-run','complete') then raise exception 'Unsupported queue action'; end if;
 if p_action in ('queue-all','queue-and-run') then perform public.brickalpha_request_refresh(null,v_owner); end if;
 if p_action='complete' then
   select * into v_item from public.inventory_items where id=p_payload->>'id' and owner_id=v_owner for update;
   if not found then raise exception 'Queued item not found'; end if;
   if not v_item.refresh_requested or p_payload->>'version' is distinct from md5(to_jsonb(v_item)::text) then raise exception using errcode='P0001',message='Item changed or request was replaced. Reload before saving research.'; end if;
   select * into v_job from public.price_refresh_jobs where inventory_id=v_item.id and owner_id=v_owner for update;
   if p_payload?'leaseToken' then
     if v_job.status is distinct from 'running' or v_job.lease_token::text is distinct from p_payload->>'leaseToken' or v_job.requested_at is distinct from v_item.refresh_requested_at then raise exception using errcode='P0001',message='Research lease was replaced'; end if;
   elsif v_job.status='running' and v_job.lease_until>v_now then raise exception using errcode='P0001',message='Another worker is researching this request'; end if;
   if p_payload->>'condition' is distinct from v_item.condition or jsonb_typeof(p_payload->'market') is distinct from 'number' then raise exception 'Exact condition and numeric market value required'; end if;
   v_market:=round((p_payload->>'market')::numeric,2);
   if v_market<=0 or v_market>100000 or v_market='NaN'::numeric then raise exception 'Invalid market value; prior price preserved'; end if;
   if v_item.market>0 and (v_market>v_item.market*4 or v_market<v_item.market*.25) then raise exception 'Suspicious price movement; manual review required'; end if;
   v_sources:=p_payload->'sources';
   if jsonb_typeof(v_sources) is distinct from 'array' then raise exception 'Supporting sources required'; end if;
   if jsonb_array_length(v_sources)<4 or jsonb_array_length(v_sources)>50 then raise exception 'Four supporting source domains required'; end if;
   for v_source in select value from jsonb_array_elements(v_sources) loop
     if jsonb_typeof(v_source)<>'object' or nullif(btrim(v_source->>'source'),'') is null or coalesce(v_source->>'url','')!~'^https://[a-zA-Z0-9.-]+/' or v_source->>'condition' is distinct from v_item.condition then raise exception 'Each source requires its name, HTTPS URL and matching condition'; end if;
     if v_source->>'url'~*'^https://([^/]*\.)?(amazon\.[^/]+|stockx\.com)(/|$)' or concat_ws(' ',v_source->>'kind',v_source->>'source')~*'part[ _-]*out' then raise exception 'Excluded valuation source'; end if;
   end loop;
   if not public.has_four_viable_market_sources(v_sources) then raise exception 'Four distinct viable source domains required'; end if;
   if not exists(select 1 from jsonb_array_elements(v_sources) s where s->>'kind'='sold') then raise exception 'Completed-sale evidence is required; estimates alone cannot complete a refresh'; end if;
   insert into public.price_history(inventory_id,owner_id,price_date,market) values(v_item.id,v_owner,(v_now at time zone 'UTC')::date,v_market)
   on conflict(inventory_id,price_date) do update set market=excluded.market where public.price_history.owner_id=excluded.owner_id;
   if not found then raise exception 'History ownership mismatch'; end if;
   perform set_config('brickalpha.price_action','research',true);
   perform set_config('brickalpha.queue_action','complete',true);
   update public.inventory_items set market=v_market,market_sources=v_sources,last_updated=v_now,refresh_requested=false where id=v_item.id and owner_id=v_owner;
   perform set_config('brickalpha.queue_action',v_previous,true);
   perform set_config('brickalpha.price_action','',true);
   insert into public.price_refresh_jobs(inventory_id,owner_id,requested_at,status,attempted_at,result,updated_at)
   values(v_item.id,v_owner,v_item.refresh_requested_at,'complete',v_now,p_payload-'version'-'leaseToken',v_now)
   on conflict(inventory_id) do update set requested_at=excluded.requested_at,status='complete',attempted_at=v_now,lease_until=null,lease_token=null,next_attempt_at=null,error=null,result=excluded.result,updated_at=v_now;
   return jsonb_build_object('ok',true,'processed',1,'id',v_item.id,'market',v_market);
 end if;
 select count(*),count(*) filter(where i.refresh_requested),
 count(*) filter(where i.refresh_requested and (j.inventory_id is null or j.requested_at is distinct from i.refresh_requested_at or j.status='pending' and (j.next_attempt_at is null or j.next_attempt_at<=v_now) or j.status='running' and (j.lease_until is null or j.lease_until<=v_now))),
 count(*) filter(where i.refresh_requested and j.requested_at is not distinct from i.refresh_requested_at and j.status='running' and j.lease_until>v_now),
 count(*) filter(where i.refresh_requested and j.requested_at is not distinct from i.refresh_requested_at and j.status='needs_review'),
 count(*) filter(where i.refresh_requested and j.requested_at is not distinct from i.refresh_requested_at and j.status='pending' and j.next_attempt_at>v_now)
 into v_total,v_queued,v_ready,v_running,v_review,v_waiting from public.inventory_items i left join public.price_refresh_jobs j on j.inventory_id=i.id and j.owner_id=i.owner_id where i.owner_id=v_owner;
 select coalesce(jsonb_agg(jsonb_build_object('inventory_id',i.id,'setNumber',i.set_number,'name',i.name,'status',j.status,'error',j.error,'nextAttemptAt',j.next_attempt_at)),'[]') into v_attempts from public.inventory_items i join public.price_refresh_jobs j on j.inventory_id=i.id and j.owner_id=i.owner_id and j.requested_at is not distinct from i.refresh_requested_at where i.owner_id=v_owner and i.refresh_requested;
 if p_action in ('next','run','queue-and-run') then
   select coalesce(jsonb_agg(x.item order by x.sort_number,x.set_number,x.condition,x.id),'[]') into v_items from (
     select jsonb_build_object('id',i.id,'setNumber',i.set_number,'name',i.name,'condition',i.condition,'currentMarket',i.market,'lastUpdated',i.last_updated,'requestedAt',i.refresh_requested_at,'version',md5(to_jsonb(i)::text)) item,
       case when split_part(btrim(i.set_number),'-',1)~'^[0-9]{1,12}$' then split_part(btrim(i.set_number),'-',1)::bigint else 9999999999999 end sort_number,i.set_number,i.condition,i.id
     from public.inventory_items i where i.owner_id=v_owner and i.refresh_requested order by sort_number,i.set_number,i.condition,i.id limit least(500,greatest(1,coalesce((p_payload->>'limit')::int,100)))
   ) x;
 end if;
 return jsonb_build_object('ok',true,'total',v_total,'queued',v_queued,'ready',v_ready,'running',v_running,'needsReview',v_review,'waitingRetry',v_waiting,'processed',0,'passFinished',v_ready=0,'items',v_items,'attempts',v_attempts);
end $$;

-- Route the old completion entrypoint through the same atomic checks. Reject zero here too.
create or replace function public.complete_price_refresh(p_id text,p_market numeric,p_sources jsonb default '[]')
returns table(item_id text,item_set_number text,item_market numeric,item_last_updated timestamptz)
language plpgsql security invoker set search_path='' as $$
declare v_owner uuid:=public.brickalpha_require_owner(); v_row public.inventory_items%rowtype;
begin
 select * into v_row from public.inventory_items where id=p_id and owner_id=v_owner for update;
 if not found then raise exception 'Inventory item not found'; end if;
 perform public.brick_alpha_queue('complete',jsonb_build_object('id',p_id,'version',md5(to_jsonb(v_row)::text),'condition',v_row.condition,'market',p_market,'sources',p_sources),v_owner);
 return query select id,set_number,market,last_updated from public.inventory_items where id=p_id and owner_id=v_owner;
end $$;

-- Safe to rerun. No grants to anon, and RLS stays enabled on all collection tables.
do $$ declare f record; begin
 for f in select p.oid::regprocedure signature from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname='public' and p.proname in ('brickalpha_require_owner','brickalpha_inventory_version','brickalpha_inventory','brickalpha_save_inventory','brickalpha_request_refresh','claim_price_refresh','brickalpha_finish_attempt','brick_alpha_queue','complete_price_refresh') loop
   execute format('revoke all on function %s from public,anon',f.signature);
   execute format('grant execute on function %s to authenticated,service_role',f.signature);
 end loop;
end $$;

-- Reject old clients replaying prices through ordinary full-row saves.
create or replace function public.brickalpha_guard_prices()
returns trigger language plpgsql security invoker set search_path='' as $$
begin
 if (new.market is distinct from old.market or new.market_sources is distinct from old.market_sources or new.last_updated is distinct from old.last_updated)
    and coalesce(current_setting('brickalpha.price_action',true),'') not in ('manual','research') then
   raise exception 'This app version cannot safely save prices. Reload the repaired app or use the atomic price-refresh RPC.';
 end if;
 if old.market>0 and coalesce(new.market,0)<=0 then raise exception 'A valid saved market value cannot be replaced by zero or null'; end if;
 return new;
end $$;
drop trigger if exists inventory_guard_prices on public.inventory_items;
create trigger inventory_guard_prices before update on public.inventory_items for each row execute function public.brickalpha_guard_prices();
