import { createClient } from "@supabase/supabase-js";
import { runResearchBatch } from "@/lib/queue-processor";
export const runtime="nodejs";
export const dynamic="force-dynamic";
export const maxDuration=60;
const URL="https://nhxprfrnjsbdqisbdgvh.supabase.co";
const KEY="sb_publishable_QoISdu3jE90BNFnkDby-6g_48bU2tpt";
function json(data:unknown,status=200){return Response.json(data,{status,headers:{"Cache-Control":"no-store"}});}
async function client(request:Request){
 const auth=request.headers.get("authorization");
 if(!auth?.startsWith("Bearer "))throw new Error("Authentication required");
 const db=createClient(URL,KEY,{global:{headers:{Authorization:auth}},auth:{persistSession:false,autoRefreshToken:false,detectSessionInUrl:false}});
 const {data,error}=await db.auth.getUser(auth.slice(7));
 if(error||!data.user)throw new Error("Authentication required");
 const {data:owner,error:ownerError}=await db.rpc("brickalpha_require_owner");
 if(ownerError)throw new Error(ownerError.message);
 if(typeof owner!=="string"||!owner)throw new Error("Collection access required");
 return {db,owner};
}
function failure(e:unknown){const error=e instanceof Error?e.message:"Queue request failed";return json({ok:false,error},/Authentication required/.test(error)?401:/account|collection access|anonymous session|Sign in/i.test(error)?403:500);}
export async function GET(request:Request){
 try{const {db,owner}=await client(request);const {data,error}=await db.rpc("brick_alpha_queue",{p_action:"next",p_payload:{limit:500},p_owner_id:owner});if(error)throw new Error(error.message);return json(data);}catch(e){return failure(e);}
}
export async function POST(request:Request){
 try{
  const {db,owner}=await client(request);
  let body:{action?:string;retry?:boolean};try{body=await request.json();}catch{return json({ok:false,error:"Invalid JSON"},400);}
  if(!body||typeof body!=="object"||!["run","queue-all","queue-and-run"].includes(body.action||"run"))return json({ok:false,error:"Unsupported action"},400);
  if(body.action==="queue-all"||body.action==="queue-and-run"){
   const {error}=await db.rpc("brickalpha_request_refresh",{p_owner_id:owner});if(error)throw new Error(error.message);
   if(body.action==="queue-all"){const {data,error:stateError}=await db.rpc("brick_alpha_queue",{p_action:"status",p_owner_id:owner});if(stateError)throw new Error(stateError.message);return json(data);}
  }
  return json(await runResearchBatch(db,owner,body.retry===true));
 }catch(e){return failure(e);}
}
