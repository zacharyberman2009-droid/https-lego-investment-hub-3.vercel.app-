export const dynamic="force-dynamic";
export function GET(){return Response.json({ok:true,repair:"2026-10-16",queuePolicy:"explicit-only"},{headers:{"Cache-Control":"no-store"}});}
