export { GET, POST } from "../update/route";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 60;
