"use client";
import { useState } from "react";
import { getInventory, requestPriceRefresh } from "@/lib/storage";
import RefreshQueue from "@/components/RefreshQueue";
export default function Research() {
  const [setNumber, setSetNumber] = useState(""), [note, setNote] = useState(""), [busy, setBusy] = useState(false);
  async function queue() {
    setBusy(true);
    try {
      const number = setNumber.trim().replace(/-1$/, ""), items = await getInventory();
      const matches = items.filter(i => i.setNumber.trim().replace(/-1$/, "") === number);
      if (!matches.length) { setNote("Add that set to your inventory before requesting research."); return; }
      await requestPriceRefresh(matches.map(x => x.id));
      setNote(`${matches.length} matching inventory entries queued. Ask ChatGPT: ‘Update my current Brick Alpha queue.’`);
    } catch (e) { setNote(e instanceof Error ? e.message : "Could not queue this set."); }
    finally { setBusy(false); }
  }
  return <><div className="header"><div><div className="eyebrow">Collection price research</div><h1>Price Research</h1><div className="muted">Research public completed sales and update your collection.</div></div></div>
    <section className="card"><div className="research-search"><label htmlFor="research-set-number" className="muted">Set number</label><input id="research-set-number" className="input" placeholder="e.g. 75313" value={setNumber} onChange={e => setSetNumber(e.target.value)} /><button className="btn accent" onClick={() => void queue()} disabled={!setNumber.trim() || busy}>{busy ? "Queueing…" : "Queue this set"}</button></div><p role="status" aria-live="polite">{note}</p></section>
    <RefreshQueue />
  </>;
}
