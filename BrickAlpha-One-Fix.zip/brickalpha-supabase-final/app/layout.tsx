import "./globals.css";
import Nav from "@/components/Nav";
import CollectionGate from "@/components/CollectionGate";
export const metadata={title:"BrickAlpha",description:"LEGO inventory and market intelligence"};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body><Nav/><main className="main"><CollectionGate>{children}</CollectionGate></main></body></html>}
