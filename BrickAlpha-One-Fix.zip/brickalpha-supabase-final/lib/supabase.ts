"use client";
import { createClient } from "@supabase/supabase-js";

// This publishable key is intended for browsers. RLS protects collection data.
export const supabase = createClient(
  "https://nhxprfrnjsbdqisbdgvh.supabase.co",
  "sb_publishable_QoISdu3jE90BNFnkDby-6g_48bU2tpt",
  { auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true } },
);

export async function ensureSupabaseUser() {
  const { data, error } = await supabase.auth.getUser();
  if (error || !data.user) throw new Error("Sign in to the account linked to your Brick Alpha collection.");
  return data.user;
}

export async function collectionOwnerId() {
  await ensureSupabaseUser();
  const { data, error } = await supabase.rpc("brickalpha_require_owner");
  if (error) throw new Error(error.message);
  if (typeof data !== "string" || !data) throw new Error("This account is not linked to your collection. Sign in with your linked email.");
  return data;
}
