"use client";
import { LegoItem, WatchItem, MarketSource, PriceSnapshot } from "./types";
import { supabase, collectionOwnerId } from "./supabase";

function changed() { window.dispatchEvent(new Event("inventory-change")); }
function dbToItem(row:any, history:PriceSnapshot[]=[]):LegoItem {
  return {
    id:row.id,setNumber:row.set_number,name:row.name,theme:row.theme||"",year:row.year??undefined,
    condition:row.condition,quantity:Number(row.quantity??1),cost:Number(row.cost??0),market:Number(row.market??0),
    storePrice:Number(row.store_price??0),status:row.status,location:row.location||"",imageUrl:row.image_url||undefined,
    notes:row.notes||"",lastUpdated:row.last_updated||undefined,marketSources:(row.market_sources||[]) as MarketSource[],
    refreshRequested:Boolean(row.refresh_requested),refreshRequestedAt:row.refresh_requested_at||undefined,
    recordVersion:row.record_version,queueStatus:row.queue_status,queueError:row.queue_error||undefined,history,
  };
}
export async function getInventory():Promise<LegoItem[]> {
  await collectionOwnerId();
  // Aggregate RPC returns the complete history, including rows beyond PostgREST's row cap.
  const {data,error}=await supabase.rpc("brickalpha_inventory");
  if(error)throw new Error(error.message);
  const history=new Map<string,PriceSnapshot[]>();
  for(const h of data.history||[]){const points=history.get(h.inventory_id)||[];points.push({date:h.price_date,market:Number(h.market)});history.set(h.inventory_id,points);}
  return (data.items||[]).map((row:any)=>dbToItem(row,history.get(row.id)||[]));
}
const fields={setNumber:"set_number",name:"name",theme:"theme",year:"year",condition:"condition",quantity:"quantity",cost:"cost",market:"market",storePrice:"store_price",status:"status",location:"location",notes:"notes",imageUrl:"image_url"} as const;
export async function upsertInventoryItem(item:LegoItem, original?:LegoItem) {
  await collectionOwnerId();
  const patch:Record<string,unknown>={};
  for(const [key,column] of Object.entries(fields)){
    const field=key as keyof typeof fields;
    if(!original || item[field]!==original[field]) patch[column]=item[field]??null;
  }
  if(original && Object.keys(patch).length===0)return;
  const {error}=await supabase.rpc("brickalpha_save_inventory",{
    p_id:item.id,p_patch:patch,p_new:!original,p_expected_version:original?.recordVersion??null,p_expected_market:original?.market??null,
  });
  if(error)throw new Error(error.message);
  // Price/history/queue fields from an old edit form never go through an upsert.
  changed();
}
export async function deleteInventoryItem(id:string){
  const ownerId=await collectionOwnerId();
  const {data,error}=await supabase.from("inventory_items").delete().eq("id",id).eq("owner_id",ownerId).select("id");
  if(error)throw new Error(error.message);
  if(!data?.length)throw new Error("This entry was not deleted. Reload and check your account.");
  changed();
}
// Compatibility for old imports: opening the app only reads the central collection.
export async function importLocalInventoryIfNeeded(){return {imported:0,items:await getInventory()};}
export function getLocalInventoryBackup():LegoItem[]{
  if(typeof window==="undefined")return[];
  for(const key of ["lih_inventory_v2","lih_inventory_v1"]){try{const value=JSON.parse(localStorage.getItem(key)||"null");if(Array.isArray(value))return value;}catch{}}
  return[];
}
export function getLocalWatchlistBackup():WatchItem[]{if(typeof window==="undefined")return[];try{return JSON.parse(localStorage.getItem("lih_watch_v1")||"[]")}catch{return[]}}
export async function requestPriceRefresh(ids?:string[]){
  const selected=ids===undefined?null:[...new Set(ids.map(id=>id.trim()).filter(Boolean))];
  if(selected?.length===0)return 0;
  await collectionOwnerId();
  const {data,error}=await supabase.rpc("brickalpha_request_refresh",{p_ids:selected});
  if(error)throw new Error(error.message);
  changed();return Number(data.queued);
}
export async function getWatchlist():Promise<WatchItem[]>{const ownerId=await collectionOwnerId();const{data,error}=await supabase.from("watchlist_items").select("*").eq("owner_id",ownerId).order("created_at",{ascending:false});if(error)throw new Error(error.message);return(data||[]).map((r:any)=>({id:r.id,setNumber:r.set_number,name:r.name,targetBuyPrice:Number(r.target_price||0),currentMarket:Number(r.current_price||0),notes:r.notes||""}))}
export async function upsertWatchItem(item:WatchItem){const ownerId=await collectionOwnerId();const{error}=await supabase.from("watchlist_items").upsert({id:item.id,set_number:item.setNumber,name:item.name,target_price:item.targetBuyPrice,current_price:item.currentMarket,notes:item.notes||null,owner_id:ownerId,updated_at:new Date().toISOString()});if(error)throw new Error(error.message)}
export async function deleteWatchItem(id:string){const ownerId=await collectionOwnerId();const{error}=await supabase.from("watchlist_items").delete().eq("id",id).eq("owner_id",ownerId);if(error)throw new Error(error.message)}
export function money(v:number){return new Intl.NumberFormat("en-US",{style:"currency",currency:"USD",maximumFractionDigits:2}).format(Number.isFinite(v)?v:0)}
export function pct(v:number){return `${v>=0?"+":""}${v.toFixed(1)}%`}
export function valueAt(item:LegoItem,days:number){const target=Date.now()-days*86400000;const points=[...(item.history||[])].sort((a,b)=>new Date(a.date).getTime()-new Date(b.date).getTime());let best=points[0]?.market??item.market;for(const p of points){if(new Date(p.date).getTime()<=target)best=p.market;else break}return best}
