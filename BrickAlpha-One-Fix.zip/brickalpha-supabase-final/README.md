# Brick Alpha — consolidated repair, October 16, 2026

This is the repaired Next.js application for the existing `lego-investment-hub-3` Vercel project. Its folder in the existing GitHub repository must remain `brickalpha-supabase-final`.

The database repair, server worker and website were deployed on October 16. The live repair health endpoint returned HTTP 200. Upload this folder to the existing repository to make the source durable and prevent a later Git deployment from restoring the older application.

## Apply this one package

1. Download and unzip `BrickAlpha-One-Fix.zip`. On a Mac, double-click it.
2. Open the existing repository: https://github.com/zacharyberman2009-droid/https-lego-investment-hub-3.vercel.app-
3. Select branch **main**. Stay on the repository's top-level page, where the older Brick Alpha folders are listed.
4. Click **Add file → Upload files**. Drag the unzipped **brickalpha-supabase-final** folder onto the upload page. Drag the folder itself, rather than the ZIP or the files inside it. This retains the correct paths.
5. Check that the upload lists paths such as `brickalpha-supabase-final/lib/storage.ts` and `brickalpha-supabase-final/components/CollectionGate.tsx`. There must be exactly one `brickalpha-supabase-final` in each path. A doubled folder name means you uploaded from inside the existing app folder; cancel and start from the repository's top-level page.
6. Enter commit message **Apply consolidated Brick Alpha repair**. Select **Commit directly to the main branch** and click **Commit changes**. Existing matching code files are replaced; the other app folders and central inventory are not imported or reset.
7. In Vercel, open the existing project **lego-investment-hub-3 → Settings → Build and Deployment → Root Directory**. Set it to `brickalpha-supabase-final` if it differs, then save. Keep the existing project and domains. The framework is Next.js, with `npm run build`; Node.js is 24.x.
8. Open **Deployments**. Wait for the deployment created by your new GitHub commit to show **Ready**. If no deployment starts, open the newest deployment's menu and choose **Redeploy**, using the latest source from main and the Production environment.
9. Check the installed code at https://lego-investment-hub-3.vercel.app/api/brick-alpha/health . It must return `"repair":"2026-10-16"` and `"queuePolicy":"explicit-only"`. A 404 or a different repair value means the new source has not reached that URL yet.
10. Open https://lego-investment-hub-3.vercel.app/inventory and hard-refresh with **Command + Shift + R**. Sign in with the account already linked to this collection: **zacharyberman2009@gmail.com**. An existing session belonging to the original collection owner also remains valid.

## Fix the old localhost sign-in redirect

In the existing Supabase project `nhxprfrnjsbdqisbdgvh`, open **Authentication → URL Configuration**:

- **Site URL:** `https://lego-investment-hub-3.vercel.app`
- Add **Redirect URL:** `https://lego-investment-hub-3.vercel.app/inventory`
- Save. Request a new sign-in link from the repaired app; older emailed links keep their original destination.

The code requests the current app's `/inventory` address and never silently creates another anonymous account. Password sign-in is available if this account already has a password. No new account or inventory import is needed.

## What this repair changes

- Collection access uses the existing authorized account-to-owner mapping. Missing/invalid access displays a sign-in screen, rather than another empty collection.
- Page visits, reloads, stale dates, new entries and normal edits do not queue requests or import old browser inventory.
- Queue and Queue all use an atomic RPC. Empty selections do nothing. A fresh explicit request gets a new generation and can retry an entry previously needing review.
- Old clients cannot requeue entries through ordinary PATCH/upsert, or overwrite market prices through a stale full-row save.
- Inventory edits send only the fields the user changed. Optimistic versions reject conflicting edits; refreshed prices and history survive a previously opened edit form.
- A server-side scheduled worker processes existing explicit requests with the site closed. Its minute checks do no external HTTP work while the queue is idle. Short, leased batches continue the backlog and retry transient source failures with bounded backoff. A single-flight admission guard prevents overlapping scheduled batches; timed-out scheduled requests recover automatically.
- Concurrent/late workers cannot complete or fail a replacement request. Successful research saves market value, sources, timestamp, daily history and job completion in one transaction.
- Research keeps exact set and condition distinctions, excludes incomplete builds, accessories, mixed lots, presales and large outliers, and never replaces valid prices with zero/null. Used-incomplete entries require a missing-parts profile and manual review.
- No paid pricing API is required. Public BrickLink guides are checked; unavailable guides are reported honestly. Condition-matched completed eBay sales reported by PriceCharting anchor the automatic median; BrickEconomy and BrickPriceWatch are contextual cross-checks. PriceCharting and its linked eBay records are one correlated evidence stream. Amazon and StockX are excluded. Four supporting source domains are required; if evidence cannot satisfy the checks, the old price stays saved and the request remains for retry/review.
- Unvalued entries display **Needs valuation**. Queue errors and research/review states are visible. All dated price history is loaded, including history beyond the REST API row limit.

## Verify after installation

1. Confirm the existing collection loads (287 entries and 452 units before subsequent user changes).
2. Note the queue count; reload twice. Visits must add no requests. Background research may reduce the count.
3. Queue one entry; only that entry gets a new request. Open an edit, update a note, and save; its queue and any newer researched price must survive.
4. Close the page; queued requests stay in the server database and the scheduled worker continues.
5. An entry with insufficient matching sales stays queued with a reason. A review state does not mean the collection disappeared or that the set is worth zero.

## Implementation and verification

- `supabase/consolidated-repair.sql` and `supabase/background-repair.sql`: exact backend repair already applied to the existing database. These are retained for review/recovery; do not paste them again as an installation step.
- `supabase/functions/brickalpha-worker/`: deployed worker source. Runtime service credentials stay in Supabase, and the worker webhook secret is generated in encrypted Vault storage; neither is included in this package.
- `npm run build`, `node scripts/verify-queue.cjs`, and `node scripts/verify-market.cjs` passed under Node 24.19.0.
- Transactional database tests passed for account mapping, owner isolation, all inventory/history rows, explicit queue scope, numeric set order, duplicate claims, zero rejection, condition matching, atomic completion, stale edits, late-worker results and single-flight scheduling. Test fixtures rolled back.
- Local HTTP checks confirmed `/inventory` renders the collection gate, `/api/update` returns 401 without authentication, and `/api/brick-alpha/health` returns this repair version.
- The live scheduled-worker connection check returned HTTP 200, and live batches completed real price refreshes. Live testing also caught and corrected overlapping scheduled invocations and retry handling for superseded research. Before/after protected-field checksums matched.
- A live signed-out browser check confirmed the collection sign-in screen. An authenticated account walkthrough was not completed. The local Playwright executable was unavailable; the included optional `scripts/verify-browser.cjs` is for a developer with Playwright installed and uses a simulated account for its signed-in portion. Real database and HTTP checks were verified separately.

`supabase/verify-consolidated.sql` compares the aggregate API response against current authorized inventory/history counts. Run the fixture only inside a rollback transaction; its synthetic test rows must never be committed.
