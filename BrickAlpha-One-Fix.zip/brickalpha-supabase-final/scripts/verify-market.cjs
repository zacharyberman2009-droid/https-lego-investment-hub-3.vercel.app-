const assert = require('node:assert/strict');
const fs = require('node:fs');
const Module = require('node:module');
const path = require('node:path');
const filename = path.resolve('lib/public-market.ts');
const compiled = Module.stripTypeScriptTypes(fs.readFileSync(filename, 'utf8')).replace('import { load } from "cheerio";', 'const { load } = require("cheerio");').replaceAll('export ', '') + '\nmodule.exports = { parseSales, saleMedian, secondary };';
const unit = new Module(filename, module); unit.paths = module.paths; unit._compile(compiled, filename);
const { parseSales, saleMedian, secondary } = unit.exports;
const now = Date.parse('2026-10-09T00:00:00Z');
const row = (id, title, amount, extra = '') => `<tr><td class="date">2026-10-07</td><td class="title"><a href="https://www.ebay.com/itm/${id}">${title}</a></td><td class="numeric"><span class="js-price">$${amount}</span>${extra}</td></tr>`;
const html = '<h1>Hyena Droid Bomber #8016</h1><div class="completed-auctions-new"><table>' +
  row(100, 'LEGO 8016 sealed', 100, '<span class="js-price listed-price-inline">$150</span>') +
  row(101, 'LEGO 8016 sealed', 105) + row(102, 'LEGO 8016 sealed', 110) +
  row(103, 'LEGO 8016 sealed', 900) + row(104, 'LEGO 8016 used complete', 20) +
  row(105, 'LEGO 8016 box only', 10) + row(106, 'LEGO 8016 no minifigures', 25) +
  row(107, 'LEGO 8016 lot of 2 sealed', 200) + row(108, 'LEGO 8019 sealed', 90) +
  row(109, 'LEGO 8016 New Other', 30) + row(110, 'LEGO 8016 Droid (Only)', 10) + '</table></div>';
const parsed = parseSales(html, '8016', 'New/Sealed', now);
assert.equal(parsed.length, 4, 'mixed conditions, accessories, multiple-set lots, wrong sets must be excluded');
assert.equal(parsed[0].price, 100, 'accepted offer price must win over list price');
const result = saleMedian(parsed, now);
assert.equal(result.market, 105); assert.equal(result.comps.length, 3); assert.equal(result.excluded, 1);
assert.throws(() => saleMedian(parsed.slice(0, 2), now), /Fewer than three/);
assert.throws(() => parseSales(html, '8019', 'New/Sealed', now), /different set/);
const model = secondary('BrickEconomy', { html: '<h1>Poinsettia 10370</h1><div id="ContentPlaceHolder1_PanelSetPricing">Retail price $49.99 Market price $44.24</div>', url: 'https://www.brickeconomy.com/set/10370-1/' }, '10370', 'New/Sealed', '2026-10-09');
assert.equal(model.value, 44.24, 'secondary current market must take precedence over original retail');
assert.equal(model.kind, 'estimate');
console.log('Market integrity checks passed: condition, exact set, accepted offer, lot exclusion, outliers and sparse evidence.');

const compactModel = secondary('BrickEconomy', { html: '<h1>Grand Emporium 10211</h1><div id="ContentPlaceHolder1_PanelSetPricing"><div>New/Sealed Value</div><div>$465.76</div><div>Used Value</div><div>$309.65</div></div>', url: 'https://www.brickeconomy.com/set/10211-1/' }, '10211', 'Used Complete', '2026-10-11');
assert.equal(compactModel.value, 309.65, 'adjacent pricing elements must parse without literal separator spaces');
assert.equal(compactModel.observedCondition, 'Used Complete');
const presales='<h1>Dustmark Keep #910064</h1><div class="completed-auctions-new"><table>'+row(200,'LEGO 910064 preorder sealed',500)+row(201,'LEGO 910064 presale new',510)+row(202,'LEGO 910064 sealed bags no box',300)+row(203,'LEGO 910064 sealed damaged box',400)+'</table></div>';
assert.equal(parseSales(presales,'910064','New/Sealed',now).length,0,'presales and non-sealed-box conditions cannot become in-hand sealed sales');
const uncertainUsed='<h1>LEGO 8016</h1><div class="completed-auctions-cib"><table>'+row(300,'LEGO 8016 used',20)+row(301,'LEGO 8016 used complete with minifigures',40)+'</table></div>';
assert.equal(parseSales(uncertainUsed,'8016','Used Complete',now).length,1,'CIB category alone is insufficient proof of completeness');
console.log('PASS: preorder exclusion and explicit used completeness.');
