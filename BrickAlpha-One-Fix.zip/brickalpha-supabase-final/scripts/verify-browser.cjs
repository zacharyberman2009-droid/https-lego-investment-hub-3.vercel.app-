const assert=require('node:assert/strict');
const {spawn}=require('node:child_process');
const {chromium}=require('playwright');
const server=spawn(process.execPath,['node_modules/next/dist/bin/next','start','--hostname','127.0.0.1','--port','3104'],{stdio:['ignore','pipe','pipe']});
const origin='http://127.0.0.1:3104';
const waitReady=new Promise((resolve,reject)=>{let output='';const timer=setTimeout(()=>reject(new Error('Server startup timeout: '+output)),12000);server.stdout.on('data',chunk=>{output+=chunk.toString();if(output.includes('Ready in')){clearTimeout(timer);resolve();}});server.stderr.on('data',chunk=>{output+=chunk.toString();});server.on('exit',code=>{clearTimeout(timer);reject(new Error('Server exited '+code+': '+output));});});
(async()=>{
 let browser;
 try{
  await waitReady;
  const unauth=await fetch(origin+'/api/update');assert.equal(unauth.status,401);assert.equal((await unauth.json()).ok,false);
  browser=await chromium.launch({headless:true,args:['--no-sandbox']});
  const context=await browser.newContext({viewport:{width:1400,height:1000}});
  const page=await context.newPage();const errors=[];page.on('pageerror',e=>errors.push(e.message));
  let authPosts=0;
  await page.route('**/auth/v1/**',route=>{if(route.request().method()==='POST')authPosts++;return route.fulfill({status:401,contentType:'application/json',body:JSON.stringify({message:'No session'})});});
  await page.addInitScript(()=>localStorage.setItem('lih_inventory_v2',JSON.stringify([{id:'obsolete-copy',setNumber:'99999'}])));
  await page.goto(origin+'/inventory');await page.getByRole('heading',{name:'Open your Brick Alpha collection'}).waitFor();
  assert.equal(await page.getByText('No sets found.').count(),0);assert.equal(authPosts,0,'signed-out visits must not create users or email links');
  await page.reload();await page.getByRole('heading',{name:'Open your Brick Alpha collection'}).waitFor();assert.equal(authPosts,0);
  await context.close();
  // Browser behavior fixture. Database authorization and transactions are tested separately in SQL.
  const signed=await browser.newContext({viewport:{width:1400,height:1000}});const current=await signed.newPage();current.on('pageerror',e=>errors.push(e.message));
  const user={id:'de2303f1-977b-4910-af56-fde283ba33f1',email:'fixture@example.org',role:'authenticated',aud:'authenticated',is_anonymous:false,app_metadata:{provider:'email'},user_metadata:{}};
  const token='eyJhbGciOiJIUzI1NiJ9.'+Buffer.from(JSON.stringify({sub:user.id,exp:2100000000,role:'authenticated'})).toString('base64url')+'.test';
  await signed.addInitScript(({user,token})=>localStorage.setItem('sb-nhxprfrnjsbdqisbdgvh-auth-token',JSON.stringify({access_token:token,refresh_token:'fixture-only',token_type:'bearer',expires_in:3600,expires_at:2100000000,user})),{user,token});
  const item={id:'fixture-a',owner_id:'334066cd-53e9-44d7-8495-88f1b64a2290',set_number:'10326',name:'Test museum',condition:'New/Sealed',quantity:2,cost:100,market:292.5,store_price:300,status:'Hold',theme:'Icons',notes:'original notes',record_version:'fixture-version',refresh_requested:false,queue_status:'complete',last_updated:'2026-10-14T00:00:00Z'};
  const writes=[];
  await signed.route('**/auth/v1/**',route=>route.fulfill({status:200,contentType:'application/json',body:JSON.stringify(user)}));
  await signed.route('**/rest/v1/rpc/**',async route=>{
   const name=route.request().url().split('/').pop();const args=route.request().postDataJSON()||{};let reply;
   if(name==='brickalpha_require_owner')reply=item.owner_id;
   else if(name==='brickalpha_inventory')reply={items:[item],history:[]};
   else if(name==='brickalpha_request_refresh'){writes.push({name,args});item.refresh_requested=true;item.queue_status='pending';reply={ok:true,queued:1};}
   else if(name==='brickalpha_save_inventory'){writes.push({name,args});Object.assign(item,args.p_patch);reply={ok:true};}
   else throw new Error('Unexpected RPC '+name);
   await route.fulfill({status:200,contentType:'application/json',body:JSON.stringify(reply)});
  });
  await signed.route(origin+'/api/update',route=>route.fulfill({status:200,contentType:'application/json',body:JSON.stringify({ok:true,total:1,queued:item.refresh_requested?1:0,processed:0,attempts:[]})}));
  await current.goto(origin+'/inventory');await current.getByText('Test museum',{exact:true}).waitFor();assert.equal(writes.length,0);
  await current.reload();await current.getByText('Test museum',{exact:true}).waitFor();assert.equal(writes.length,0);
  await current.getByRole('button',{name:'Queue',exact:true}).click();await current.getByText('Queued',{exact:true}).first().waitFor();assert.equal(writes.length,1);assert.deepEqual(writes[0].args.p_ids,['fixture-a']);
  await current.getByRole('button',{name:'Edit',exact:true}).click();await current.getByRole('heading',{name:'Edit LEGO set'}).waitFor();
  item.market=310;
  await current.locator('textarea').fill('changed notes');await current.getByRole('button',{name:'Save changes',exact:true}).click();await current.getByText('$310.00',{exact:true}).waitFor();
  const save=writes.find(w=>w.name==='brickalpha_save_inventory');assert.deepEqual(save.args.p_patch,{notes:'changed notes'});assert.equal(item.refresh_requested,true);
  assert.deepEqual(errors,[],'browser should have no uncaught errors');
  await signed.close();console.log('PASS: real local API rejects unauthenticated access; browser shows sign-in without anonymous fallback; simulated signed-in visits are read-only; Queue is scoped; stale edit preserves refreshed price.');
 }finally{if(browser)await browser.close();server.kill('SIGTERM');}
})().catch(e=>{console.error(e);process.exitCode=1;server.kill('SIGTERM');});
