const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const swc=require('next/dist/build/swc');
const writes=[];
let lookups=0;
const rows=[{id:'a',set_number:'10326',name:'Museum',condition:'New/Sealed',quantity:1,cost:100,market:292.50,store_price:300,status:'Hold',owner_id:'owner',record_version:'v1',refresh_requested:false}];
const snapshots=Array.from({length:1634},(_,i)=>({inventory_id:'a',price_date:'2026-10-01',market:i}));
const db={collectionOwnerId:async()=>{lookups++;return 'owner';},supabase:{rpc:async(name,args)=>{
 if(name==='brickalpha_inventory')return {data:{items:structuredClone(rows),history:snapshots},error:null};
 writes.push({name,args});
 return {data:{ok:true,queued:name==='brickalpha_request_refresh'?(args.p_ids===null?rows.length:args.p_ids.length):0},error:null};
}}};
async function readModule(file,replacements){const source=(await swc.transform(fs.readFileSync(file,'utf8'),{filename:file,jsc:{parser:{syntax:'typescript',tsx:file.endsWith('.tsx')},transform:{react:{runtime:'automatic'}}},module:{type:'commonjs'}})).code;const mod={exports:{}};vm.runInNewContext(source,{module:mod,exports:mod.exports,require:n=>replacements[n]||require(n),window:new EventTarget(),localStorage:{getItem:()=>JSON.stringify([{id:'old-browser-copy'}])},Event,Date,console,Intl,Map,Set});return mod.exports;}
(async()=>{
 await swc.loadBindings();
 const storage=await readModule('lib/storage.ts',{'./supabase':db});
 for(let i=0;i<2;i++)await storage.importLocalInventoryIfNeeded();
 assert.equal(writes.length,0,'opening/reopening and old local backups must never write central data');
 const inventory=await storage.getInventory();
 assert.equal(inventory[0].history.length,1634,'history beyond the REST row cap must remain available');
 const before=lookups;assert.equal(await storage.requestPriceRefresh([]),0);assert.equal(lookups,before);
 await storage.requestPriceRefresh(['a','a','']);
 assert.equal(writes[0].name,'brickalpha_request_refresh');assert.deepEqual(JSON.parse(JSON.stringify(writes[0].args)),{p_ids:['a']});
 await storage.requestPriceRefresh();assert.equal(writes[1].args.p_ids,null,'Queue all must be explicit');
 const original=inventory[0];await storage.upsertInventoryItem({...original,notes:'Edited notes',refreshRequested:true},original);
 const save=writes[2];assert.equal(save.name,'brickalpha_save_inventory');
 assert.deepEqual(JSON.parse(JSON.stringify(save.args.p_patch)),{notes:'Edited notes'},'a stale form may only send the fields the user changed');
 assert.equal(save.args.p_new,false);assert.equal(save.args.p_expected_version,'v1');
 const count=writes.length;await storage.upsertInventoryItem(original,original);assert.equal(writes.length,count,'unchanged forms must not write');
 const authSource=fs.readFileSync('lib/supabase.ts','utf8');assert.ok(!authSource.includes('signInAnonymously'),'no anonymous fallback');
 console.log('PASS: read-only visits, no automatic import, full history, empty/selected/all queue scopes and stale edit payload preservation.');
})().catch(e=>{console.error(e);process.exitCode=1;});
