"""Collect public exact-set sales evidence without paid APIs; never write inventory.

Run with an exported inventory JSON. Every result is checkpointed for review.
PriceCharting and its linked eBay sales are one correlated evidence stream.
BrickEconomy and BrickPriceWatch are secondary estimates, never sale substitutes.
"""
import argparse, concurrent.futures, datetime as dt, hashlib, json, re, statistics, threading, time
from pathlib import Path
from urllib.parse import urlparse, urljoin
import requests
from bs4 import BeautifulSoup
from lxml import html as lhtml

TODAY = dt.datetime.now(dt.timezone.utc).date()
STAMP = dt.datetime.now(dt.timezone.utc).isoformat()
LOCK = threading.Lock()
HEADERS = {"User-Agent": "Mozilla/5.0", "Accept": "text/html"}
OFFLINE = False

def dollars(text):
    m = re.search(r'\$\s*([\d,]+(?:\.\d+)?)', text or '')
    return float(m.group(1).replace(',', '')) if m else None

def fetch(url, folder, name):
    path = folder / (name + '.html')
    if path.exists(): return path.read_text(), url
    unavailable = folder / (name + '-unavailable.json')
    if name == 'bl' and unavailable.exists():
        raise ValueError(json.loads(unavailable.read_text())['error'])
    if OFFLINE: raise ValueError('Source unavailable in this research pass: ' + url)
    response = requests.get(url, headers=HEADERS, timeout=(8, 20))
    if response.status_code != 200: raise ValueError(f'HTTP {response.status_code}: {url}')
    if len(response.content) < 4000 or re.search(r'<title>[^<]*(captcha|access denied|verify|just a moment)', response.text, re.I):
        raise ValueError('Source requires human verification: ' + url)
    path.write_text(response.text)
    return response.text, response.url

def pc_sales(html, set_number, condition):
    root = lhtml.fromstring(html)
    relevant = root.xpath("//h1 | //div[contains(@class, 'completed-auctions-')] | //*[@id='complete_price' or @id='new_price' or @id='used_price']")
    soup = BeautifulSoup(''.join(lhtml.tostring(node, encoding='unicode') for node in relevant), 'lxml')
    h1 = soup.find('h1')
    if not h1 or not re.search(r'(?<!\d)' + re.escape(set_number) + r'(?!\d)', h1.get_text()):
        raise ValueError('PriceCharting page does not identify this exact set')
    group = ['new'] if condition == 'New/Sealed' else ['cib', 'used', 'loose-and-manual']
    rows, excluded, seen = [], [], set()
    for tag in group:
        for row in soup.select('.completed-auctions-' + tag + ' tr'):
            date, title, price = row.select_one('.date'), row.select_one('.title a'), row.select_one('td.numeric .js-price')
            if not date or not title or not price: continue
            title_text = title.get_text(' ', strip=True)
            try: date_value = dt.date.fromisoformat(date.get_text(strip=True))
            except ValueError: continue
            p = dollars(price.get_text())
            href = title.get('href', '').split('?')[0]
            key = href or (str(date_value), title_text, p)
            if key in seen: continue
            seen.add(key)
            reason = None
            if date_value > TODAY or (TODAY-date_value).days > 180: reason = 'outside 180-day window'
            elif not p or p <= 0: reason = 'invalid price'
            elif not re.search(r'(?<!\d)' + re.escape(set_number) + r'(?!\d)', title_text): reason = 'set number not explicit'
            elif re.search(r'\b(only|replacement|light(?:ing)? kit|led kit|empty box|custom|compatible|knock.?off|bulk|bundle|lot of|set of [2-9]|[2-9] ?x|x ?[2-9])\b', title_text, re.I): reason = 'partial, accessory or multiple-set lot'
            elif re.search(r'\b(no|without|missing)\s+(all\s+)?(mini.?fig(?:ure)?s?|figs?|figures?|droids?|pieces?|parts?)\b|build only|ship only|vehicle only|incomplete|\b\d{1,2}%\s*complete', title_text, re.I): reason = 'incomplete set'
            elif condition == 'New/Sealed' and re.search(r'\b(used|built|assembled|opened|open box|unsealed|new other|no box|without box|pieces only)\b', title_text, re.I): reason = 'not sealed'
            elif condition != 'New/Sealed' and re.search(r'\b(sealed|misb|nib|brand new|new in box)\b', title_text, re.I): reason = 'sealed condition mismatch'
            elif condition != 'New/Sealed' and tag != 'cib' and not re.search(r'\b(100%|complete|with (?:mini)?figures|w/\s*(?:mini)?figs)\b', title_text, re.I): reason = 'completeness unverified'
            record = {'date':str(date_value),'title':title_text,'price':p,'url':href,'category':tag}
            if reason: record['reason']=reason;excluded.append(record)
            else: rows.append(record)
    rows.sort(key=lambda r:r['date'],reverse=True)
    guides = {k:dollars(soup.select_one('#'+k+' .price').get_text()) if soup.select_one('#'+k+' .price') else None for k in ['complete_price','new_price','used_price']}
    return rows, excluded, guides

def be_value(html, number, condition):
    soup = BeautifulSoup(html, 'lxml')
    if not soup.h1 or not re.search(r'(?<!\d)'+number+r'(?!\d)',soup.h1.get_text()): raise ValueError('BrickEconomy exact-set mismatch')
    panel=soup.find(id='ContentPlaceHolder1_PanelSetPricing') or soup.find(id='ContentPlaceHolder1_UpdatePanelSetPricing')
    if not panel: raise ValueError('BrickEconomy pricing panel missing')
    text=panel.get_text(' ',strip=True)
    pattern=r'New/Sealed\s+Value\s+(\$[\d,.]+)' if condition=='New/Sealed' else r'Used\s+Value\s+(\$[\d,.]+)'
    m=re.search(pattern,text)
    observed=condition
    if not m:
        m=re.search(r'(?:New/Sealed\s+Value|Market price)\s+(\$[\d,.]+)',text) or re.search(r'Retail price\s+(\$[\d,.]+)',text);observed='New/Sealed'
    if not m: raise ValueError('BrickEconomy market context unavailable')
    return dollars(m.group(1)), observed, text[:1400]

def bpw_value(html, number, condition):
    soup=BeautifulSoup(html,'lxml')
    if not soup.h1 or not re.search(r'(?<!\d)'+number+r'(?!\d)',soup.h1.get_text()): raise ValueError('BrickPriceWatch exact-set mismatch')
    text=soup.get_text(' ',strip=True)
    pattern=r'New / sealed value\s+(\$[\d,.]+)' if condition=='New/Sealed' else r'Used value\s+(\$[\d,.]+)'
    m=re.search(pattern,text)
    observed=condition
    if not m:
        m=re.search(r'(?:New / sealed value|Latest monthly close|Latest estimate)\s+(\$[\d,.]+)',text);observed='New/Sealed'
    if not m: raise ValueError('BrickPriceWatch market context unavailable')
    check=re.search(r'Last market check\s+([^ ]+)',text)
    return dollars(m.group(1)), observed, check.group(1) if check else None

def robust(rows):
    # Prefer the shortest window with at least five exact-condition observations.
    chosen=[]; window=180
    for days in [7,30,90,180]:
        candidates=[r for r in rows if (TODAY-dt.date.fromisoformat(r['date'])).days<=days]
        if len(candidates)>=5 or days==180:
            chosen=candidates; window=days;break
    if len(chosen)<3: raise ValueError('Fewer than three recent condition-matched completed sales')
    values=[r['price'] for r in chosen];med=statistics.median(values)
    mad=statistics.median([abs(x-med) for x in values])
    bound=max(3*1.4826*mad,med*.30)
    kept=[r for r in chosen if abs(r['price']-med)<=bound]
    if len(kept)<3: raise ValueError('Too few completed sales after outlier removal')
    return round(statistics.median(r['price'] for r in kept),2),kept,window,[r for r in chosen if r not in kept]

def research(group, cache):
    number=group[0]['set_number'].strip().removesuffix('-1');condition=group[0]['condition']
    result={'set_number':number,'condition':condition,'ids':[r['id'] for r in group],'checked_at':STAMP,'prior_market':[r['market'] for r in group],'status':'needs_review','sources':[],'errors':[]}
    folder=cache/number;folder.mkdir(parents=True,exist_ok=True)
    pc_url=next((s.get('url') for r in group for s in r.get('market_sources',[]) if 'pricecharting.com/game/' in s.get('url','')),f'https://www.pricecharting.com/search-products?type=prices&q={number}')
    source_jobs=[('pc',pc_url),('be',f'https://www.brickeconomy.com/set/{number}-1/'),('bpw',f'https://brickpricewatch.com/sets/{number}-1'),('bl',f'https://www.bricklink.com/catalogPG.asp?S={number}-1&colorID=0&viewExclude=Y')]
    pages={}
    # Sources for the same set are fetched sequentially; groups use bounded parallelism.
    for label,url in source_jobs:
        try:
            try:
                html,actual=fetch(url,folder,label)
            except Exception:
                if label != 'pc' or '/game/' not in url: raise
                html,actual=fetch(f'https://www.pricecharting.com/search-products?type=prices&q={number}',folder,'pc-search')
            if label=='pc' and '/game/' not in actual:
                soup=BeautifulSoup(html,'lxml')
                canonical=soup.select_one('link[rel="canonical"]')
                canonical_url=canonical.get('href','') if canonical else ''
                if '/game/' in canonical_url and soup.h1 and re.search(r'(?<!\d)'+number+r'(?!\d)',soup.h1.get_text()):
                    actual=canonical_url
                else:
                    links=[a.get('href') for a in soup.select('a[href*="/game/"]') if re.search(r'(?<!\d)'+number+r'(?!\d)',a.get_text())]
                    if len(set(links))!=1: raise ValueError('PriceCharting exact product link not uniquely resolved')
                    actual=urljoin('https://www.pricecharting.com',links[0]);html,actual=fetch(actual,folder,'pc-product')
            pages[label]=(html,actual)
        except Exception as e:
            result['errors'].append({'source':label,'error':str(e)[:220]})
            if label=='bl': (folder/'bl-unavailable.json').write_text(json.dumps({'error':str(e)[:220],'checked_at':STAMP}))
    try:
        if condition=='Used Incomplete':raise ValueError('Missing-parts profile requires manual condition review')
        rows,excluded,guides=pc_sales(*[pages['pc'][0],number,condition])
        value,kept,window,outliers=robust(rows)
        result.update({'proposed_market':value,'comps':kept,'excluded_count':len(excluded)+len(outliers),'window_days':window,'guide_values':guides,'sales_last_7_days':sum((TODAY-dt.date.fromisoformat(r['date'])).days<=7 for r in rows)})
        result['sources'].append({'source':'PriceCharting','url':pages['pc'][1],'kind':'sold','value':value,'condition':condition,'fetchedAt':STAMP,'detail':f'Median of {len(kept)} exact-set {condition} completed sales in {window} days; misclassified, incomplete, multiple-set, accessory and outlier listings excluded. Prices exclude shipping/tax where not separately reported.','comps':kept})
        result['sources'].append({'source':'eBay completed sales via PriceCharting','url':kept[0]['url'],'kind':'sold','value':value,'condition':condition,'fetchedAt':STAMP,'detail':'eBay transaction prices and dates reported by PriceCharting; correlated with the PriceCharting source, not a separate independent price estimate.','comps':kept})
        be,be_condition,be_text=be_value(pages['be'][0],number,condition);result['be_value']=be;result['be_condition']=be_condition
        result['sources'].append({'source':'BrickEconomy','url':pages['be'][1],'kind':'estimate' if be_condition==condition else 'retail','value':be,'condition':condition,'observedCondition':be_condition,'fetchedAt':STAMP,'detail':'Matching-condition model estimate or explicitly labeled sealed/retail ceiling for context. Used only to cross-check completed sales; forecasts and active offers are not the valuation anchor.'})
        bpw,bpw_condition,data_asof=bpw_value(pages['bpw'][0],number,condition);result['bpw_value']=bpw;result['bpw_condition']=bpw_condition
        result['sources'].append({'source':'BrickPriceWatch','url':pages['bpw'][1],'kind':'estimate' if bpw_condition==condition else 'retail','value':bpw,'condition':condition,'observedCondition':bpw_condition,'fetchedAt':STAMP,'dataAsOf':data_asof,'detail':f'Secondary estimate for {bpw_condition}, used as context only when the inventory condition differs. Source-reported last market check: {data_asof or "not supplied"}; older model data receives no weight in the completed-sale median.'})
        if 'bl' in pages:
            bltext=BeautifulSoup(pages['bl'][0],'lxml').get_text(' ',strip=True)
            result['bricklink_access']=bltext[:1000]
        if be_condition==condition and not .5<value/be<2: raise ValueError('Sold median and secondary estimate differ by more than 2x; manual review required')
        for prior in result['prior_market']:
            if prior and not .25<=value/prior<=4:raise ValueError('Large movement requires manual review')
        result['status']='ready'
    except Exception as e:result['errors'].append({'source':'valuation','error':str(e)[:240]})
    return result

def main():
    global OFFLINE
    p=argparse.ArgumentParser();p.add_argument('snapshot');p.add_argument('--out',required=True);p.add_argument('--workers',type=int,default=6);p.add_argument('--offline',action='store_true');args=p.parse_args();OFFLINE=args.offline
    snap=json.loads(Path(args.snapshot).read_text());rows=snap.get('queue',snap)
    groups={}
    for row in rows:groups.setdefault((row['set_number'],row['condition']),[]).append(row)
    dest=Path(args.out);dest.mkdir(parents=True,exist_ok=True);cache=dest/'sources';cache.mkdir(exist_ok=True)
    ordered=sorted(groups.values(),key=lambda g:(int(re.match(r'\d+',g[0]['set_number']).group()),g[0]['condition']))
    results=[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as pool:
        futures={pool.submit(research,g,cache):g for g in ordered}
        for future in concurrent.futures.as_completed(futures):
            try:r=future.result()
            except Exception as e:
                g=futures[future];r={'set_number':g[0]['set_number'],'condition':g[0]['condition'],'ids':[x['id'] for x in g],'status':'needs_review','errors':[str(e)]}
            results.append(r)
            (dest/'results.json').write_text(json.dumps(sorted(results,key=lambda x:(int(x['set_number']),x['condition'])),indent=2))
            print(json.dumps({'done':len(results),'total':len(ordered),'set':r['set_number'],'condition':r['condition'],'status':r['status'],'market':r.get('proposed_market'),'error':r.get('errors',[])[-1:] if r['status']!='ready' else []}),flush=True)

if __name__=='__main__':main()
